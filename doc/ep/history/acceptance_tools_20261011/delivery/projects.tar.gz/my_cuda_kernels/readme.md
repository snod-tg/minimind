# My CUDA Kernels

实践 RMSNorm、Fused Residual RMSNorm、GEMM、MoE Grouped GEMM 与 EP 张量算子。CUDA 实现和共用 common.h 位于 dev/cuda；通用 Torch 包位于 dev/pytorch/my_cuda_kernels。

## 目录与入口

| 内容 | 入口 |
| --- | --- |
| CUDA / TileLang 实现 | dev/cuda / dev/tilelang |
| 通用 Python API | [API 说明](dev/pytorch/README.md) |
| 编译 / benchmark | script/build.py / script |
| 单算子测试 | tests |
| 方案 / 指令 / 结果 | [组织约定](doc/design/project_structure.md) · [命令](doc/commands/local_workflow.md) · [整理验收](doc/results/organization_20261009.md) |
| 分析 / 图表 | analysis / figures |
| 构建 / 测量 | build / result |

| 实现 | 算子 | 报告 |
|---|---|---|
| CUDA | RMSNorm forward | [分析](analysis/cuda_rmsnorm_forward.md) |
| CUDA | RMSNorm backward | [分析](analysis/cuda_rmsnorm_backward.md) |
| CUDA | Fused Residual RMSNorm forward | [分析](analysis/cuda_fused_residual_rmsnorm_forward.md) |
| CUDA | Fused Residual RMSNorm backward | [分析](analysis/cuda_fused_residual_rmsnorm_backward.md) |
| TileLang | RMSNorm forward | [分析](analysis/tilelang_rmsnorm_forward.md) |
| TileLang | RMSNorm backward | [分析](analysis/tilelang_rmsnorm_backward.md) |
| TileLang | Fused Residual RMSNorm forward | [分析](analysis/tilelang_fused_residual_rmsnorm_forward.md) |
| TileLang | Fused Residual RMSNorm backward | [分析](analysis/tilelang_fused_residual_rmsnorm_backward.md) |
| CUDA | GEMM，固定 1024³ | [分析](analysis/gemm.md) |
| CUDA | MoE Grouped GEMM，固定总 M、可变专家分配 | [分析](analysis/grouped_gemm.md) |
| CUDA | MoE Grouped GEMM kernel9，动态总 M、BF16 模型维度 | [分析](analysis/grouped_gemm_kernel9.md) |
| PyTorch | kernel9 注册接口、工作区与权重缓存 | [分析](analysis/grouped_gemm_api.md) |


## 编译与调用

在项目根目录执行，使用已安装 PyTorch 的解释器。

```bash
python -m pip install --no-deps --no-build-isolation -e .
python script/build.py ep
python script/build.py grouped_gemm
python -m unittest tests.test_package -v

mkdir -p build/practice
nvcc -O3 -std=c++17 -arch=sm_89 dev/cuda/gemm_forward.cu -lcublas -o build/practice/gemm
./build/practice/gemm --dtype fp16 --kernel 9
nvcc -O3 -std=c++17 -arch=sm_89 dev/cuda/moe_grouped_gemm_forward.cu -lcublas -o build/practice/grouped_gemm
./build/practice/grouped_gemm --m 2048 --experts 16 --n 1024 --k 1024 --dtype fp16 --kernel 8
```

CUTLASS 对照追加 --expt-relaxed-constexpr -DUSE_CUTLASS -I "$CUTLASS_ROOT/include"。4090D 使用 sm_89。最新 Prefill/Decode 的数值、性能和适用范围见 [分析](analysis/grouped_gemm_prefill_decode.md) 与 [Decode 优化](analysis/grouped_gemm_decode.md)。

## 与 MiniMind 的关系

MiniMind 通过 `from my_cuda_kernels...` 调用通用包。Router/NCCL、完整专家 MLP、专家权重缓存、KN checkpoint、训练和整模型评估都在 [MiniMind](../minimind/readme_ep.md)。通用算子不依赖模型仓库。训练目前使用原 PyTorch 专家与 compact EP；CUDA GEMM 全层推理仍需独立数值准入。
