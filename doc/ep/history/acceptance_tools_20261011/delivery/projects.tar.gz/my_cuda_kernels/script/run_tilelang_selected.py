"""Benchmark original kernels with an explicit, bounded candidate selection.

Only the example's top-level BLOCK_N_LIST is restricted to (1,32); kernel
functions, numerical checks, split-C candidates and timing are unchanged.
BLOCK_N=128 is omitted after a >9 minute compiler run with no completed kernel.
"""
import argparse,ast,hashlib,json
from pathlib import Path

parser=argparse.ArgumentParser();parser.add_argument('source',type=Path);args=parser.parse_args()
source=args.source.resolve();text=source.read_text();tree=ast.parse(text,filename=str(source));filtered=False
for node in tree.body:
    if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='BLOCK_N_LIST' for t in node.targets):
        node.value=ast.Tuple(elts=[ast.Constant(1),ast.Constant(32)],ctx=ast.Load());filtered=True
ast.fix_missing_locations(tree)
print('BENCH_SCOPE',json.dumps(dict(source=str(source),sha256=hashlib.sha256(source.read_bytes()).hexdigest(),full_block_n=[1,32] if filtered else [1],split_c='all original candidates',excluded_block_n=[128] if filtered else [],reason='compile exceeded 9 minutes before any kernel execution' if filtered else '')),flush=True)
exec(compile(tree,str(source),'exec'),{'__name__':'__main__','__file__':str(source),'__package__':None})
