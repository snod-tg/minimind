"""Separate Graph execution from eager submission latency."""
import json,argparse
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
p=argparse.ArgumentParser();p.add_argument('--results',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
rows=json.loads(a.results.read_text());labels=['M=1 | down','M=16 | gate/up','M=2912 | down','M=22463 | gate/up','E=16, M=2048 | FP16']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.facecolor':'#f8fafc','grid.color':'#cbd5e1','grid.alpha':.45})
fig,axes=plt.subplots(1,2,figsize=(13,5),sharey=True);colors=plt.get_cmap('tab10').colors;y=np.arange(len(rows));width=.24
for ax,metric,title in zip(axes,['graph_us','eager_wall_us'],['CUDA Graph: execution','Eager: enqueue + final synchronize']):
 for i,(key,label) in enumerate([('native_full','Native bridge'),('api_out','PyTorch preallocated'),('api_functional','PyTorch allocating')]):
  ax.barh(y+(i-1)*width,[r[metric][key] for r in rows],height=width,color=colors[i],label=label)
 ax.set_xscale('log');ax.set_xlabel('Latency per call (us, log scale)');ax.set_title(title);ax.grid(axis='x');ax.set_axisbelow(True)
axes[0].set_yticks(y,labels);axes[0].invert_yaxis()
fig.suptitle('Kernel9: PyTorch interface cost',x=.02,ha='left',fontweight='bold')
fig.text(.02,.9,'RTX 4090D GPU1 | same inputs, same full kernel9 | 7 rotated rounds | 2026-10-07',fontsize=9,color='#475569')
handles,names=axes[0].get_legend_handles_labels();fig.legend(handles,names,loc='lower center',ncol=3,frameon=False,bbox_to_anchor=(.5,.045))
fig.text(.02,.01,'Eager includes CPU submission gaps. Graph capture excludes Python/check/allocation preparation cost. No model speedup is measured.',fontsize=8,color='#475569')
fig.tight_layout(rect=[0,.14,1,.87]);a.output.parent.mkdir(parents=True,exist_ok=True);fig.savefig(a.output,dpi=180,bbox_inches='tight')
