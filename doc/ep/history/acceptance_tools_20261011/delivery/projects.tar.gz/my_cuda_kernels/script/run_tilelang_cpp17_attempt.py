"""Run the unchanged TileLang examples with an explicit C++17 compile flag.

CUDA 12.4 + GCC 9 cannot compile the checkout's default C++20 device path.
The adaptation is confined to the test process; it does not edit TileLang or kernels.
"""
import argparse
import runpy
from pathlib import Path
import tilelang

parser=argparse.ArgumentParser()
parser.add_argument('source',type=Path)
args=parser.parse_args()
original_jit=tilelang.jit

def jit_with_cpp17(*values,**kwargs):
    kwargs['compile_flags']=list(kwargs.get('compile_flags') or [])+['-std=c++17']
    return original_jit(*values,**kwargs)

tilelang.jit=jit_with_cpp17
print('COMPAT: appended -std=c++17 to TileLang JIT compile_flags',flush=True)
runpy.run_path(str(args.source.resolve()),run_name='__main__')
