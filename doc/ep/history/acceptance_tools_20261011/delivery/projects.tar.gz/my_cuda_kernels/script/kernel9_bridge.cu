// Stage-three benchmark adapter. The PyTorch registration is a separate stage.
#define main grouped_program_main
#include "../dev/cuda/moe_grouped_gemm_forward.cu"
#undef main
namespace k9_bench {
static std::string error;
struct Runner {
    void *a,*b,*c;const int64_t* counts;int dtype,experts,m,n,k,config,blocks;
    DeviceBuffer<GroupedMetadata9> metadata{1};
    DeviceBuffer<float> partial;
    Runner(int dt,int e,int mm,int nn,int kk,const void* ct,void* aa,void* bb,void* cc,int cf,int bl)
        :a(aa),b(bb),c(cc),counts(static_cast<const int64_t*>(ct)),dtype(dt),
         experts(e),m(mm),n(nn),k(kk),config(cf),blocks(bl),partial(cf>=6?size_t(mm)*nn*(cf==6?4:8):0) {
        if(dt<0 || dt>1 || !moe_is_kernel9_target(e,nn,kk) || mm<0 || cf<0 || cf>7 || bl<0 || (cf>=6 && mm>64))
            throw std::runtime_error("unsupported kernel9 adapter arguments");
    }
    void run(cudaStream_t stream,int mode) {
        if(mode<0 || mode>2)throw std::runtime_error("mode: 0=full 1=compute 2=metadata");
        if(dtype==0)moe_launch_kernel9(static_cast<half*>(c),static_cast<half*>(a),static_cast<half*>(b),
            metadata.ptr,counts,experts,m,n,k,stream,config,blocks,mode!=1,mode!=2,partial.ptr);
        else moe_launch_kernel9(static_cast<__nv_bfloat16*>(c),static_cast<__nv_bfloat16*>(a),static_cast<__nv_bfloat16*>(b),
            metadata.ptr,counts,experts,m,n,k,stream,config,blocks,mode!=1,mode!=2,partial.ptr);
    }
};
extern "C" const char* k9_error(){return error.c_str();}
extern "C" int k9_default_config(int m,int n,int k){return moe_kernel9_default_config(m,n,k);}
extern "C" void* k9_create(int dt,int e,int m,int n,int k,const void* counts,void* a,void* b,void* c,int config,int blocks) {
    try{
        if(config==-1)config=moe_kernel9_default_config(m,n,k);
        if(dt<0 || dt>1 || !moe_is_kernel9_target(e,n,k) || m<0 || config<0 || config>7 || blocks<0 || (config>=6 && m>64))
            throw std::runtime_error("unsupported kernel9 adapter arguments");
        return new Runner(dt,e,m,n,k,counts,a,b,c,config,blocks);
    }
    catch(const std::exception& ex){error=ex.what();return nullptr;}
}
extern "C" int k9_run(void* runner,void* stream,int mode) {
    try{static_cast<Runner*>(runner)->run(static_cast<cudaStream_t>(stream),mode);return 0;}
    catch(const std::exception& ex){error=ex.what();return -1;}
}
extern "C" void k9_destroy(void* runner){delete static_cast<Runner*>(runner);}
}
