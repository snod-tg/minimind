#!/usr/bin/env bash
set -euo pipefail
CHECK_BINARY="${CHECK_BINARY:?set the native check_kernel9 binary}"
SANITIZER_OUT="${SANITIZER_OUT:?set a fresh result directory}"
SANITIZER_BIN="${SANITIZER_BIN:-/usr/local/cuda/bin/compute-sanitizer}"
export CUDA_VISIBLE_DEVICES="${BENCH_GPU:-1}"
if [[ -e "$SANITIZER_OUT" ]]; then
    printf 'Choose a fresh sanitizer output directory\n' >&2
    exit 1
fi
mkdir -p "$SANITIZER_OUT"
for tool in ${SANITIZER_TOOLS:-memcheck racecheck synccheck}; do
    for dtype in bf16 fp16; do
        for shape in '2432 768' '768 2432' '1024 1024'; do
            read -r n k <<< "$shape"
            for pattern in regular tiny; do
                # All shapes/types for memory; long-K/tail paths and short Split-K for synchronization.
                if [[ "$tool" != memcheck ]]; then
                    if ! [[ "$dtype $n $pattern" == 'bf16 2432 tiny' ||
                            "$dtype $n" == 'bf16 768' || "$dtype $n" == 'fp16 1024' ]]; then
                        continue
                    fi
                fi
                logfile="$SANITIZER_OUT/${tool}_${dtype}_${n}x${k}_${pattern}.log"
                "$SANITIZER_BIN" --tool "$tool" --error-exitcode 97 \
                    "$CHECK_BINARY" "$n" "$k" "$dtype" "$pattern" > "$logfile" 2>&1
                grep -q 'ALL CHECKS PASSED' "$logfile"
                if [[ "$tool" == racecheck ]]; then
                    grep -q 'RACECHECK SUMMARY: 0 hazards.*0 errors, 0 warnings' "$logfile"
                else
                    grep -q 'ERROR SUMMARY: 0' "$logfile"
                fi
                printf 'PASSED %s %s %sx%s %s\n' "$tool" "$dtype" "$n" "$k" "$pattern"
            done
        done
    done
done
