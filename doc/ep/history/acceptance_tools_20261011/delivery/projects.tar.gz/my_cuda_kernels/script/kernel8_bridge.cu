// Benchmark adapter: use the published kernels and preallocate routing metadata.
#define main grouped_program_main
#include "../dev/cuda/moe_grouped_gemm_forward.cu"
#undef main
namespace k8_bench {
static std::string error;
struct Runner {
    half *a,*b,*c;int version;
    DeviceBuffer<int> counts,offsets;DeviceBuffer<GroupTile> tiles;
    Runner(int v,const std::vector<int>& ct,half* aa,half* bb,half* cc)
        :a(aa),b(bb),c(cc),version(v),counts(ct.size()),offsets(ct.size()+1),
         tiles((v==7?make_fixed_tiles(ct):make_kernel8_tiles(ct)).size()) {
        std::vector<int> off(ct.size()+1);
        for(size_t e=0;e<ct.size();++e)off[e+1]=off[e]+ct[e];
        counts.upload(ct);offsets.upload(off);
        tiles.upload(v==7?make_fixed_tiles(ct):make_kernel8_tiles(ct));
    }
    void run(cudaStream_t stream) {
        if(version==7)moe_grouped_gemm_forward_kernel7<<<tiles.count,128,30720,stream>>>(c,a,b,counts.ptr,offsets.ptr,tiles.ptr);
        else moe_grouped_gemm_forward_kernel8<<<tiles.count,128,30720,stream>>>(c,a,b,counts.ptr,offsets.ptr,tiles.ptr);
        CUDA_CHECK(cudaGetLastError());
    }
};
extern "C" const char* k8_error(){return error.c_str();}
extern "C" void* k8_create(int v,const int* ct,int e,void* a,void* b,void* c) {
    try {
        std::vector<int> counts(ct,ct+e);
        for(int m:counts)if(m<0)throw std::runtime_error("negative count");
        if(v!=7 && v!=8)throw std::runtime_error("adapter supports only 7/8");
        if(!(v==7?moe_is_fixed_target(counts,1024,1024):moe_is_kernel8_target(counts,1024,1024)))
            throw std::runtime_error("outside specialized target");
        return new Runner(v,counts,(half*)a,(half*)b,(half*)c);
    }catch(const std::exception& ex){error=ex.what();return nullptr;}
}
extern "C" int k8_run(void* runner,void* stream) {
    try{static_cast<Runner*>(runner)->run(static_cast<cudaStream_t>(stream));return 0;}
    catch(const std::exception& ex){error=ex.what();return -1;}
}
extern "C" void k8_destroy(void* runner){delete static_cast<Runner*>(runner);}
}
