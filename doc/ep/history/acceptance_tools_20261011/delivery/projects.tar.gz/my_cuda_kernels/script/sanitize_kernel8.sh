#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${KERNEL8_RESULT:-$ROOT/result/20261006/moe_grouped_kernel8}"
cd "$ROOT"
export CUDA_VISIBLE_DEVICES="${BENCH_GPU:-3}"
counts=(
  '0,1,2,7,8,15,16,17,31,32,33,63,64,65,129,1565'
  '1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2047'
  '0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2048'
)
for index in 0 1 2; do
  for tool in memcheck racecheck synccheck; do
    /usr/local/cuda/bin/compute-sanitizer --tool "$tool" --error-exitcode 99 "$OUT/grouped" --dtype fp16 --n 1024 --k 1024 --counts "${counts[$index]}" --kernel 8 --no-bench >"$OUT/${tool}_${index}.log" 2>&1
    printf '%s %s PASS\n' "$tool" "$index"
  done
done
