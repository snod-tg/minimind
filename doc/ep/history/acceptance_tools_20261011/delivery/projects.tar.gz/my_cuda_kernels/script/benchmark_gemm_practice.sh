#!/usr/bin/env bash
# 从项目根目录执行：CUDA_VISIBLE_DEVICES=1 bash script/benchmark_gemm_practice.sh result/gemm_practice
set -euo pipefail
out_dir="${1:-result/gemm_practice}"
mkdir -p "$out_dir"
grouped_binary=./result/build/moe_grouped_gemm_forward
if [[ -x ./result/build/moe_grouped_gemm_cutlass ]]; then
    grouped_binary=./result/build/moe_grouped_gemm_cutlass
fi
for dtype in fp32 fp16 bf16; do
    ./result/build/gemm_forward --m 1024 --n 1024 --k 1024 --dtype "$dtype" --repeats 100 \
        > "$out_dir/gemm_${dtype}.txt"
    "$grouped_binary" --m 512 --experts 64 --n 512 --k 512 --dtype "$dtype" --repeats 100 \
        > "$out_dir/grouped_small_${dtype}.txt"
done
"$grouped_binary" --m 2048 --experts 8 --n 512 --k 512 --dtype fp16 --repeats 100 \
    > "$out_dir/grouped_large_fp16.txt"
"$grouped_binary" --m 4096 --experts 64 --n 512 --k 512 --distribution skewed --dtype fp16 --repeats 50 \
    > "$out_dir/grouped_skewed_fp16.txt"
"$grouped_binary" --counts 0,1,17,33,257,0 --n 513 --k 257 --dtype fp16 --repeats 50 \
    > "$out_dir/grouped_tail_fp16.txt"
printf 'Completed: %s\n' "$out_dir"
