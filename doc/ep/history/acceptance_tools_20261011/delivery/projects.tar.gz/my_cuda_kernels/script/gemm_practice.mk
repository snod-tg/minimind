# 从项目根目录执行：make -f script/gemm_practice.mk
# CUDA 12.x；4090D 用 sm_89，其他 GPU 通过 ARCH=sm_80 等覆盖。
NVCC ?= nvcc
ARCH ?= sm_89
FLAGS = -O3 -std=c++17 -arch=$(ARCH) --expt-relaxed-constexpr
BUILD_DIR = result/build
HEADERS = dev/cuda/common.h dev/cuda/gemm_kernels.cuh
CUTLASS_ROOT ?=

.PHONY: all cutlass check check-cutlass
all: result/build/gemm_forward result/build/moe_grouped_gemm_forward

result/build/gemm_forward: dev/cuda/gemm_forward.cu $(HEADERS) | $(BUILD_DIR)
	$(NVCC) $(FLAGS) $< -lcublas -o $@

result/build/moe_grouped_gemm_forward: dev/cuda/moe_grouped_gemm_forward.cu $(HEADERS) dev/cuda/gemm_cutlass.cuh | $(BUILD_DIR)
	$(NVCC) $(FLAGS) $< -lcublas -o $@

cutlass: result/build/moe_grouped_gemm_cutlass

result/build/moe_grouped_gemm_cutlass: dev/cuda/moe_grouped_gemm_forward.cu $(HEADERS) dev/cuda/gemm_cutlass.cuh | $(BUILD_DIR)
	test -n "$(CUTLASS_ROOT)" && test -f "$(CUTLASS_ROOT)/include/cutlass/cutlass.h"
	$(NVCC) $(FLAGS) -DUSE_CUTLASS -I "$(CUTLASS_ROOT)/include" $< -lcublas -o $@

check: all
	./result/build/gemm_forward --self-test
	./result/build/moe_grouped_gemm_forward --self-test

check-cutlass: cutlass
	./result/build/moe_grouped_gemm_cutlass --self-test

$(BUILD_DIR):
	mkdir -p $@
