"""Plot same-round kernel8/CUTLASS results for variable counts and fixed total M."""
import argparse,json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
parser=argparse.ArgumentParser()
parser.add_argument('--results',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args()
rows=json.loads(args.results.read_text())
labels={'original':'Original allocation','balanced':'Balanced','odd_rows':'Nearly balanced + tails','tails':'Small / empty experts + tails','skewed':'Skewed','single':'Single active expert','random':'Random split'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.titlesize':12,'axes.labelsize':10,'axes.spines.top':False,'axes.spines.right':False,'axes.facecolor':'#f8fafc','figure.facecolor':'white','grid.color':'#cbd5e1','grid.alpha':.45})
colors=plt.get_cmap('tab10').colors
fig,ax=plt.subplots(figsize=(11,6));y=np.arange(len(rows));width=.34
for offset,label,color in [(-width/2,'kernel8',colors[1]),(width/2,'CUTLASS',colors[0])]:
 bars=ax.barh(y+offset,[r['medians_us'][label] for r in rows],height=width,label=label,color=color)
 ax.bar_label(bars,fmt='%.2f',padding=3,fontsize=9)
ax.set_yticks(y,labels=[labels[r['scenario']] for r in rows]);ax.invert_yaxis();ax.set_xlabel('Latency (us)')
ax.set_xlim(0,max(r['medians_us']['kernel8'] for r in rows)*1.15);ax.grid(axis='x');ax.set_axisbelow(True)
ax.legend(frameon=False,loc='upper left',bbox_to_anchor=(1.01,1))
ax.set_title('MoE Grouped GEMM: variable counts, total M=2048',loc='left',fontweight='bold',pad=28)
ax.text(0,1.025,'RTX 4090D GPU3 | E=16, N=K=1024, FP16 | CUDA Graph, 7 rounds | 2026-10-06',transform=ax.transAxes,fontsize=9,color='#475569')
fig.tight_layout();args.output.parent.mkdir(parents=True,exist_ok=True)
fig.savefig(args.output,dpi=180,facecolor='white',bbox_inches='tight')
print(args.output)
