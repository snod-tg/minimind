#!/usr/bin/env python3
"""Regenerate ten publication figures from the local, ignored experiment archive."""
import argparse,json,re
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

OPS=('rmsnorm_forward','rmsnorm_backward','fused_residual_rmsnorm_forward','fused_residual_rmsnorm_backward')
COLORS=plt.get_cmap('tab10').colors
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.titlesize':12,
 'axes.labelsize':10,'axes.spines.top':False,'axes.spines.right':False,
 'axes.facecolor':'#f8fafc','figure.facecolor':'white','grid.color':'#cbd5e1','grid.alpha':.45})

def parse_cuda(files):
 records={}
 for file in files:
  kernel=None
  for line in file.read_text().splitlines():
   m=re.search(r'Using kernel (\d+)',line)
   if m:kernel=int(m[1])
   m=re.search(r'(?:\[(fp32|fp16|bf16)\]\s*)?block_size\s+(\d+)\s*\|\s*time\s+([\d.]+)\s*ms\s*\|\s*bandwidth\s+([\d.]+)',line)
   if m and kernel is not None:
    dtype=m[1] or 'fp32';block=int(m[2]);records[(kernel,dtype,block)]={'us':float(m[3])*1000,'gbps':float(m[4])}
 return records

def save(fig,out):
 fig.savefig(out,dpi=180,facecolor='white',bbox_inches='tight');plt.close(fig);print(out)

def cuda_plot(op,data,out):
 files=[data/'result/20260831'/f'{op}.txt',data/'result/20260902'/op/f'{op}.txt']
 records=parse_cuda(files);fig,axes=plt.subplots(1,3,figsize=(13,4.7),sharex=True)
 for ax,dtype in zip(axes,('fp32','fp16','bf16')):
  for kernel in sorted({k for k,d,b in records if d==dtype}):
   bs=sorted(b for k,d,b in records if k==kernel and d==dtype)
   ax.plot(bs,[records[(kernel,dtype,b)]['us'] for b in bs],'-o',color=COLORS[(kernel-1)%10],lw=1.8,ms=4,label=f'kernel{kernel}')
  ax.set_title(dtype.upper());ax.set_xscale('log',base=2);ax.set_yscale('log');ax.set_xticks([32,64,128,256,512,1024],labels=['32','64','128','256','512','1024']);ax.set_xlabel('Block size');ax.grid(True,which='major');ax.tick_params(axis='x',labelsize=8)
 axes[0].set_ylabel('Latency (us), log scale');handles,labels=axes[0].get_legend_handles_labels()
 fig.legend(handles,labels,loc='lower center',ncol=min(6,len(handles)),frameon=False,bbox_to_anchor=(.5,-.015))
 fig.suptitle(op.replace('_',' ').title(),x=.5,y=1.03,fontweight='bold');fig.text(.5,.95,'RTX 3060 Laptop | N=8192, C=768 | historical CUDA Event measurements (2026-08-31 / 09-02)',ha='center',fontsize=9,color='#475569')
 fig.tight_layout(rect=(0,.13,1,.93));save(fig,out/f'cuda_{op}.png');return records

def parse_tile(file):
 rows=[]
 for line in file.read_text().splitlines():
  if '参考实现' in line:continue
  m=re.search(r'整行版(?:\s+BLOCK_N=(\d+))?[^:]*:\s*([\d.]+)\s*ms',line)
  if m:rows.append({'label':f'full BN={m[1] or "1"}','us':float(m[2])*1000,'kind':'full'});continue
  m=re.search(r'splitc BN=(\d+)\s+BC=(\d+)[^:]*:\s*([\d.]+)\s*ms',line)
  if m:rows.append({'label':f'split BN={m[1]}, BC={m[2]}','us':float(m[3])*1000,'kind':'split'})
 return rows

def tile_plot(op,data,out):
 rows=parse_tile(data/'result/20261005/tilelang'/f'{op}.log')
 if not rows:raise ValueError('Missing TileLang measurements: '+op)
 fig,ax=plt.subplots(figsize=(9.5,5));y=np.arange(len(rows));ax.barh(y,[r['us'] for r in rows],color=[COLORS[0] if r['kind']=='full' else COLORS[1] for r in rows],height=.7)
 ax.set_yticks(y,labels=[r['label'] for r in rows]);ax.invert_yaxis();ax.set_xlabel('Latency (us)');ax.grid(axis='x');ax.set_axisbelow(True)
 for i,r in enumerate(rows):ax.text(r['us']*1.01,i,f"{r['us']:.1f}",va='center',fontsize=9)
 ax.set_xlim(0,max(r['us'] for r in rows)*1.18);ax.set_title('TileLang '+op.replace('_',' ').title(),loc='left',fontweight='bold',pad=28)
 shape='4096 x 4096' if op.endswith('_forward') else '1024 x 4096'
 ax.text(0,1.025,f'RTX 4090D | N x C={shape} | FP16, FP32 accumulation | 2026-10-05',transform=ax.transAxes,fontsize=9,color='#475569')
 fig.tight_layout();save(fig,out/f'tilelang_{op}.png');return rows

def gemm_plot(data,out):
 summary=json.loads((data/'result/20261004/gemm_kernel9/summary.json').read_text());fig,ax=plt.subplots(figsize=(9.5,5));x=np.arange(3);w=.30
 for j,(label,key,color) in enumerate([('kernel9','kernel9_ms',COLORS[1]),('cuBLAS','cublas_ms',COLORS[0])]):
  values=[summary[d][key]*1000 for d in ('fp32','fp16','bf16')];bars=ax.bar(x+(j-.5)*w,values,w,label=label,color=color);ax.bar_label(bars,fmt='%.2f',fontsize=9,padding=3)
 ax.set_xticks(x,labels=['FP32 (strict)','FP16','BF16']);ax.set_ylabel('Latency (us)');ax.set_ylim(0,85);ax.grid(axis='y');ax.set_axisbelow(True);ax.legend(frameon=False)
 ax.set_title('GEMM 1024 x 1024 x 1024',loc='left',fontweight='bold',pad=28);ax.text(0,1.025,'RTX 4090D | same-round median, 7 rounds | 2026-10-04',transform=ax.transAxes,fontsize=9,color='#475569');fig.tight_layout();save(fig,out/'gemm.png');return summary

def grouped_plot(data,out):
 rows=json.loads((data/'result/20261005/moe_grouped_kernel7/final_results.json').read_text());rows=[r for r in rows if r['name']!='cutlass_extra'];names={'kernel6':'kernel6','kernel7':'kernel7','cutlass_device':'CUTLASS device','cutlass_host':'CUTLASS host','deepspeed':'DeepSpeed','deeplink':'DeepLink'}
 fig,ax=plt.subplots(figsize=(9.5,5));bars=ax.bar([names[r['name']] for r in rows],[r['us'] for r in rows],color=[COLORS[1] if r['name']=='kernel7' else COLORS[0] for r in rows]);ax.bar_label(bars,fmt='%.2f',padding=3,fontsize=9)
 ax.set_ylabel('Latency (us)');ax.set_ylim(0,68);ax.grid(axis='y');ax.set_axisbelow(True);ax.tick_params(axis='x',labelsize=9)
 ax.set_title('MoE Grouped GEMM: fixed ragged shape',loc='left',fontweight='bold',pad=28);ax.text(0,1.025,'RTX 4090D | counts=[64,96,160,192] x 4 | N=K=1024, FP16 | CUDA Graph, 7 rounds',transform=ax.transAxes,fontsize=8.5,color='#475569');fig.tight_layout();save(fig,out/'grouped_gemm.png');return rows

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--repo',type=Path,default=Path(__file__).resolve().parents[1]);parser.add_argument('--data',type=Path);parser.add_argument('--without-tilelang',action='store_true');args=parser.parse_args();data=args.data or args.repo;out=args.repo/'figures';out.mkdir(parents=True,exist_ok=True)
 for op in OPS:cuda_plot(op,data,out)
 gemm_plot(data,out);grouped_plot(data,out)
 if not args.without_tilelang:
  for op in OPS:tile_plot(op,data,out)
