"""Plot measured default kernel9 against the tuned, same-round CUTLASS reference."""
import argparse
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

p=argparse.ArgumentParser()
p.add_argument('--results',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
args=p.parse_args()
rows=json.loads(args.results.read_text())
labels={
    'decode_single_gate_up':'Decode M=1 | gate/up', 'decode_single_down':'Decode M=1 | down',
    'decode_batch_gate_up':'Decode M=16 | gate/up', 'decode_batch_down':'Decode M=16 | down',
    'prefill_medium_gate_up':'Prefill M=2912 | gate/up', 'prefill_medium_down':'Prefill M=2912 | down',
    'prefill_large_gate_up':'Prefill M=22463 | gate/up', 'prefill_large_down':'Prefill M=22463 | down',
    'regression_2048':'E=16, FP16 | M=2048', 'variable_4097':'E=16, FP16 | M=4097'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.titlesize':12,
                    'axes.spines.top':False,'axes.spines.right':False,'axes.facecolor':'#f8fafc',
                    'figure.facecolor':'white','grid.color':'#cbd5e1','grid.alpha':.45})
colors=plt.get_cmap('tab10').colors
fig,(ax,ratio)=plt.subplots(1,2,figsize=(15,7),gridspec_kw={'width_ratios':[1.65,1]},sharey=True)
y=np.arange(len(rows));width=.23
for offset,key,label,color in [(-width,'CUTLASS_compute','CUTLASS compute',colors[0]),
                               (0,'kernel9_compute','kernel9 compute',colors[1]),
                               (width,'kernel9_full','kernel9 metadata + compute',colors[2])]:
    ax.barh(y+offset,[r['medians_us'][key] for r in rows],height=width,label=label,color=color)
ax.set_yticks(y,labels=[labels[r['case']] for r in rows]);ax.invert_yaxis()
ax.set_xscale('log');ax.set_xlabel('Latency (us, log scale)');ax.grid(axis='x');ax.set_axisbelow(True)
bars=ratio.barh(y,[r['compute_throughput_pct'] for r in rows],height=.55,color=colors[1])
ratio.bar_label(bars,fmt='%.1f%%',padding=4,fontsize=9)
ratio.axvline(100,color=colors[0],linestyle='--',label='CUTLASS = 100%')
ratio.set_xlim(0,max(r['compute_throughput_pct'] for r in rows)*1.24)
ratio.set_xlabel('Compute throughput / CUTLASS (%)');ratio.grid(axis='x');ratio.set_axisbelow(True)
handles,legend_labels=ax.get_legend_handles_labels()
extra,extra_labels=ratio.get_legend_handles_labels()
fig.legend(handles+extra,legend_labels+extra_labels,ncol=4,frameon=False,fontsize=9,
           loc='lower center',bbox_to_anchor=(.5,.043))
fig.suptitle('MoE Grouped GEMM: dynamic M, default kernel9',x=.02,ha='left',fontweight='bold')
fig.text(.02,.927,'RTX 4090D GPU1 | BF16 model shapes + FP16 E=16 regression | CUDA Graph, 7 rotated rounds | 2026-10-07',fontsize=9,color='#475569')
fig.text(.02,.015,'CUTLASS descriptors are prepared before timing. kernel9 full includes GPU metadata. No model/EP speedup is measured here.',fontsize=9,color='#475569')
fig.tight_layout(rect=[0,.10,1,.91])
args.output.parent.mkdir(parents=True,exist_ok=True)
fig.savefig(args.output,dpi=180,facecolor='white',bbox_inches='tight')
print(args.output)
