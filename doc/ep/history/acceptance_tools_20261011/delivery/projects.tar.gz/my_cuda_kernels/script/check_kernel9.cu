// Small native harness for Compute Sanitizer; uses the same bridge/library as benchmarks.
#include "../dev/cuda/common.h"
#include "../dev/cuda/gemm_cutlass.cuh"
extern "C" void* k9_create(int,int,int,int,int,const void*,void*,void*,void*,int,int);
extern "C" int k9_run(void*,void*,int);
extern "C" void k9_destroy(void*);
extern "C" const char* k9_error();

template<class T> void check(int n,int k,bool tiny) {
    std::vector<int> counts={0,1,2,7,8,15,16,17,31,32,33,0,0,0,0,0};
    if(tiny){counts.assign(16,0);counts[0]=1;counts[15]=15;}
    std::vector<int64_t> ct(counts.begin(),counts.end());int m=0;for(int x:counts)m+=x;
    auto a=gemm_random<T>(size_t(m)*k,17),b=gemm_random<T>(size_t(16)*k*n,43);
    DeviceBuffer<T> da(a.size()),db(b.size()),dc(size_t(m)*n),dr(dc.count);
    DeviceBuffer<int64_t> dcounts(16);da.upload(a);db.upload(b);dcounts.upload(ct);
    BlasHandle blas;int offset=0;
    for(int e=0;e<16;++e) {
        gemm_cublas(blas.handle,dr.ptr+size_t(offset)*n,da.ptr+size_t(offset)*k,
            db.ptr+size_t(e)*k*n,counts[e],n,k);offset+=counts[e];
    }
    auto ref=dr.download();
    for(int cfg=0;cfg<(tiny?8:6);++cfg)for(int blocks:{0,4}) {
        void* runner=k9_create(std::is_same_v<T,__nv_bfloat16>,16,m,n,k,dcounts.ptr,da.ptr,db.ptr,dc.ptr,cfg,blocks);
        if(!runner)throw std::runtime_error(k9_error());
        dc.poison();if(k9_run(runner,nullptr,0))throw std::runtime_error(k9_error());
        auto out=dc.download();
        if(!gemm_validate(out,ref,"kernel9"))throw std::runtime_error("output mismatch");
        offset=0;
        if(cfg==0 && blocks==0)for(int e=0;e<16;++e) {
            if(!gemm_cpu_check(a,b,out,counts[e],n,k,size_t(offset)*k,size_t(e)*k*n,size_t(offset)*n))
                throw std::runtime_error("CPU double mismatch");
            offset+=counts[e];
        }
        // Invalid GPU metadata must not access matrix memory or overwrite the poison.
        ct[0]=-1;dcounts.upload(ct);dc.poison();
        if(k9_run(runner,nullptr,0))throw std::runtime_error(k9_error());
        for(auto x:dc.download())if(std::isfinite(as_float(x)))throw std::runtime_error("invalid metadata wrote output");
        ct[0]=counts[0];dcounts.upload(ct);k9_destroy(runner);
    }
    std::fill(ct.begin(),ct.end(),0);dcounts.upload(ct);
    void* empty=k9_create(std::is_same_v<T,__nv_bfloat16>,16,0,n,k,dcounts.ptr,da.ptr,db.ptr,dc.ptr,0,0);
    if(!empty || k9_run(empty,nullptr,0))throw std::runtime_error(k9_error());
    k9_destroy(empty);
}
int main(int argc,char** argv) {
    try {
        int n=argc>1?std::stoi(argv[1]):2432,k=argc>2?std::stoi(argv[2]):768;
        std::string dtype=argc>3?argv[3]:"bf16";
        bool tiny=argc>4 && std::string(argv[4])=="tiny";
        if(dtype=="fp16")check<half>(n,k,tiny);else if(dtype=="bf16")check<__nv_bfloat16>(n,k,tiny);
        else throw std::runtime_error("dtype must be fp16/bf16");
        CUDA_CHECK(cudaDeviceSynchronize());puts("ALL CHECKS PASSED");return 0;
    }catch(const std::exception& ex){fprintf(stderr,"%s\n",ex.what());return 1;}
}
