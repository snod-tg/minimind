# 项目文档

[职责与目录](design/project_structure.md) · [当前操作指令](commands/local_workflow.md) · [整理验收](results/organization_20261009.md) · [环境](environment.md)

以下阶段文档记录对应历史实验，当前执行入口以项目 README 和操作指令为准。

| 阶段 | 说明 | 指令 | 结果 |
| --- | --- | --- | --- |
| 02_输入约定 | [design](./design/02_输入约定.md) | [commands](./commands/02_输入约定.md) | [results](./results/02_输入约定.md) |
| 03_kernel9 | [design](./design/03_kernel9.md) | [commands](./commands/03_kernel9.md) | [results](./results/03_kernel9.md) |
| 03_prefill_decode | [design](./design/03_prefill_decode.md) | [commands](./commands/03_prefill_decode.md) | [results](./results/03_prefill_decode.md) |
| 03_薄弱场景优化 | [design](./design/03_薄弱场景优化.md) | [commands](./commands/03_薄弱场景优化.md) | [results](./results/03_薄弱场景优化.md) |
| 04_PyTorch接口 | [design](./design/04_PyTorch接口.md) | [commands](./commands/04_PyTorch接口.md) | [results](./results/04_PyTorch接口.md) |
| 04_分拆算子封装 | [design](./design/04_分拆算子封装.md) | [commands](./commands/04_分拆算子封装.md) | [results](./results/04_分拆算子封装.md) |
