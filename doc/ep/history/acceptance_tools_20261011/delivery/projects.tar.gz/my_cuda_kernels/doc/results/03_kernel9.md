> 历史实验记录：保留该轮配置和结果；当前执行入口见项目 README。

# 03 kernel9：结果

## 目的与执行方案
实现三组固定 N/K 下动态 M 的 Grouped GEMM，并验证 GPU 元数据、数值、内存安全及同输入性能。状态：已完成，2026年10月7日。

[完整方案](../design/03_kernel9.md) · [逐轮指令](../commands/03_kernel9.md) · [环境](../../../minimind/doc/ep/environment_history_20261007.md)。在 RTX 4090D 物理 GPU 1 测单 Rank 本地分组计算；本阶段没有替换模型或注册 PyTorch API。

## 实现结果
- 保留 kernel8；kernel9 支持 BF16/FP16 输入输出、FP32 累加、E=1～16、GPU int64 counts、动态总 M 和专家 M、空专家和行尾块。
- `(K,N)=(768,2432)、(2432,768)、(1024,1024)`。向量化异步加载、XOR 共享内存布局、两/三阶段流水线沿用原计算核心。
- GPU counts 生成 offsets 与 Tile 前缀；CPU 只使用张量 shape 决定 grid 容量，不读取 counts；容量上界使用实际可能非空专家数 min(M,E)。提供 dense/persistent 候选。
- 小 M≤64 可用 Split-K=4/8，FP32 partial 在预分配工作区写入并合并，最后舍入输出；M=0 跳过 GPU 计算。
- CLI 的原 32768 行教学限制已解除，保留 int32 索引和 6 GiB 测试工作集检查；这不代表任意大的矩阵都能在设备上分配。

默认选路只用 M/N/K：M≤64 时，N=2432 且 M>1 用四分区，其余用八分区；较大 M 中，N=2432 或 M>4096 用 64×128/两阶段，N=768 用 32×128/三阶段，其余用 32×128/两阶段。默认 grid 为容量上界；persistent 候选已扫描。该规则来自有限样本，不承诺所有专家分配均最优。

## 正确性与动态边界
102 组随机/结构化合成输入、108 次真实分组投影回放，合计 2928 次分块/调度变体验证全部通过。真实回放来自 36 个 MLP 的 gate/up/down 输入；gate/up 单次投影分别验证，down 输入由原 BF16 autocast 激活路径构造。本阶段不将投影通过等同于完整新 MLP 或模型通过。

覆盖总 M=0～65536、单专家 M 至 32769、E=1/2/16，包含空专家、集中分配、尾块和大 M。108 次回放使用真实输入与 checkpoint；大 M 部分还包含合成矩阵，二者不混称为真实模型测量。

所有输出对照关闭 TF32 的 FP32 matmul 参考再舍入到目标类型，逐元素阈值 atol=2e-4、rtol=0.001（FP16）/0.008（BF16）。验证另外使用 CPU double 抽查；正式性能的两个最终实现各按每个非空专家最多 257 个输出复查。FP32 累加次序改变可产生舍入差异，未要求位级一致。

同一 CUDA Graph 内改变 GPU counts、改变空专家位置，168 次验证通过，不重新构建 CPU 任务表。总 M 在这项 Graph 复用测试中保持不变；不同总 M 由其他验证案例覆盖，改变输出 shape 后需要相应重新分配/捕获。

R17 的 native CLI 另完成 BF16 M=65536、BF16 M=1 Split-K 和原 kernel8 FP16 M=2048 回归，三项均输出 ALL CHECKS PASSED。

## Compute Sanitizer
22 组唯一检查全部通过：memcheck 12 组，racecheck 5 组，synccheck 5 组。内存检查覆盖三组 N/K、两种精度与 regular/tiny 两类输入；同步检查覆盖 BF16 长 K、BF16 最短 Split-K 和 FP16 回归路径，均检查全部适用配置、dense/persistent、非法 counts 的防访问分支和空输出。

R15 脚本在首个 racecheck 的零错误输出上误判失败；R16 按工具实际汇总标题修复验收并完成剩余检查，没有将脚本退出码直接视为 kernel 错误。

## 默认路径与所测最优 CUTLASS 对比
每个候选使用相同随机输入与相同 counts。性能矩阵为种子 20261007 的随机数，代表性 counts 为 M=1 的 [0,1]、M=16 的人工 [8,8]、实测 M=2912 的 [1480,1432]、实测 M=22463 的 [10986,11477]，以及两个 E=16 回归。以下不属于真实整层/模型耗时。

CUTLASS 对照为 SM80 TensorOp Grouped GEMM，使用固定 SHA256 的既有 device/host/extra 三个二进制。当前头文件检出为 b2dd65dc864e09688245b316ac46c4a6cd07e15c（v4.1.0 后 31 次提交）；此前二进制的编译提交没有单独记录，因此不将当前检出提交等同于二进制构建提交。R07 对每个负载扫描 device/host 调度及额外小 Tile 配置、三种 CTA 数；总计 1620 个有效候选、60 个资源不支持候选。R14 重新在同轮计时中运行各负载已选出的 CUTLASS 配置，并使用 kernel9 默认自动路径，没有用人工 oracle 代替默认调用。

CUDA Graph 每图 64 次调用、7 轮轮换顺序、每轮 10 次 replay，报告 Event 摊销耗时中位数，输入/输出/工作区预分配，热缓存、不锁频。初筛和编译不计时。

| 负载 | kernel9 纯计算 μs | kernel9 元数据＋计算 μs | CUTLASS 纯计算 μs | 纯计算吞吐 / CUTLASS |
| --- | ---: | ---: | ---: | ---: |
| Decode M=1，gate/up 单次 | 4.314 | 5.414 | 5.013 | 116.2% |
| Decode M=1，down | 5.611 | 6.626 | 10.603 | 189.0% |
| Decode M=16，gate/up 单次 | 5.435 | 6.467 | 4.794 | 88.2% |
| Decode M=16，down | 5.939 | 6.974 | 10.792 | 181.7% |
| Prefill M=2912，gate/up 单次 | 90.216 | 91.339 | 80.606 | 89.3% |
| Prefill M=2912，down | 101.026 | 102.128 | 80.635 | 79.8% |
| Prefill M=22463，gate/up 单次 | 658.090 | 661.619 | 591.970 | 90.0% |
| Prefill M=22463，down | 687.666 | 697.659 | 606.338 | 88.2% |
| E=16, M=2048 | 44.805 | 48.501 | 41.138 | 91.8% |
| E=16, M=4097 | 79.243 | 81.384 | 67.629 | 85.3% |

纯计算列已经准备元数据；kernel9 完整列包含 GPU 元数据生成，但 CUTLASS 列的描述符在计时前建立。吞吐百分比只比较两者纯计算，不能把完整列当成两种动态接口的公平端到端比较。独立中位数存在时钟和噪声差异，不用相减精确推算 metadata kernel 的耗时。

![kernel9 与 CUTLASS 对比](../../result/history/experiments_20261007/03_kernel9/figures/grouped_gemm_kernel9.png)

## 问题、优化与效果
第一版小 M 的 down 只有 6 个有效 CTA，长 K 流水线工作集中在很少的 SM 上。增加 Split-K 后，M=1 的 down 在默认路径为 5.611 μs，第一版同协议测量为 23.368 μs，改善约 4.16 倍；该改善仅为此算子负载，不是模型加速。

默认路径在 Prefill 仍有约 10%～20% 的纯计算差距；M=16 的 gate/up 也落后。CUTLASS 已有多种分块、流水线与调度组合，当前只对自己的有限方案做筛选，不能解释为超过所有开源实现。

ptxas 记录 kernel9 相关函数使用 32～168 个寄存器且无 spill；常规分块的动态共享内存为 18～36 KiB，小 M 分区路径为 27 KiB。寄存器范围含 metadata/reduce，不能直接等同于所有 GEMM 核心的资源量。R18 尝试对 M=2912 的 down 进行 NCU full 采样，服务器返回 ERR_NVGPUCTRPERM，未采集到性能计数器。寄存器、共享内存与有效 CTA 数可由编译记录及形状确认；访存带宽、bank conflict 和实际 occupancy 尚没有 NCU 实测证据。

## 调整闭环
| 轮次 | 证据/问题 | 调整 | 结果 |
| --- | --- | --- | --- |
| R01～R02 | 固定 FP16/1024² 路径不能直接覆盖模型 | 扩展 N/K、BF16、GPU 元数据与 6 个计算配置 | 编译、冒烟通过 |
| R03→R04 | 大 M 的浮点采样索引越界 | 改为 int64 整数索引并检查范围 | 完整边界和真实投影验证通过 |
| R05→R06 | CUTLASS 不支持配置留下 CUDA 错误；native harness 未链接共享 runtime | 记录不支持候选并清理错误，改 shared runtime 链接 | R07 完整扫描通过 |
| R07→R08 | 小 M down 计算 CTA 太少，长 K 延迟高 | 增加 Split-K 和 FP32 partial/reduce | R09 完整数值/动态验证通过 |
| R10→R11/R13 | 最快测试配置需要成为正常调用路径；CLI 行数限制不一致 | shape 默认选路、解除固定测试行数上限 | R14 默认路径同轮复测通过 |
| R15→R16 | racecheck 汇总标题与统一 grep 不同 | 按工具分别验证摘要，保留已经通过的检查 | 三种工具的 22 组检查均通过 |
| R17 | 检查最终 CLI 与旧算子兼容 | M=65536、M=1 和 kernel8 回归 | 全部通过 |
| R18 | 进一步定位 Prefill 性能差距 | 尝试 NCU full | GPU 计数器权限不足；不据此声称 bank conflict 已被排除 |

## 下一阶段
阶段 04 注册 PyTorch API，明确 tensor 属性检查、当前设备/stream、工作区管理与权重缓存。随后测完整 MLP、EP 与模型；当前数据不预先承诺它们的收益。

[最终汇总](../../result/history/experiments_20261007/03_kernel9/final_summary.json) · [默认路径实测](../../result/history/experiments_20261007/03_kernel9/R14_default_benchmark/benchmark.json)。
