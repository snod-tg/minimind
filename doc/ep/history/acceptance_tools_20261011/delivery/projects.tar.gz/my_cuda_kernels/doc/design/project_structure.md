# 算子项目组织与职责

## 目的
保留可读的 CUDA 实践代码，并提供一个模型项目能稳定导入的通用算子包。

## 执行方案
| 目录 | 职责 |
| --- | --- |
| dev/cuda | CUDA 实现、Torch C++ 绑定、共用 common.h；唯一正式 CUDA 源码 |
| dev/tilelang | TileLang 实践 |
| dev/pytorch/my_cuda_kernels | GEMM、EP 张量算子、FakeTensor/autograd 注册、工作区和库加载 |
| script | 编译、单算子 benchmark 和绘图入口 |
| tests | 单算子正确性、边界和包结构检查 |
| analysis / figures | 算子分析和配图 |
| doc/design / commands / results | 目的与闭环、可执行命令、实际结果 |
| build | 按算子与构建版本分开保存的编译产物，current 指向成功版本 |
| result | 单算子实验结果 |

通用包接受张量、counts 和工作区，不访问 MiniMind 模型对象、训练配置或 checkpoint。模型按普通 Python 依赖调用它，详见 [安装与测试命令](../commands/local_workflow.md)。

## 结果
模型路由/NCCL、专家模块缓存、完整 MLP 及 KN 转换已归到 MiniMind；正式构建只读取 dev/cuda。历史源码快照不参与默认构建或导入。

## 调整闭环
先做模块边界和接口检查，再在 CUDA 环境运行数值/安全检查，最后同轮测量 CUTLASS。数值契约、输入形状与库 ABI 变化时重新编译和验证；目录迁移不作为性能改进。
