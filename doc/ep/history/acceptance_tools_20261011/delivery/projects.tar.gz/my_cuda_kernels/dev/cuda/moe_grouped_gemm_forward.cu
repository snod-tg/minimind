// nvcc -O3 -std=c++17 -arch=sm_89 dev/cuda/moe_grouped_gemm_forward.cu -lcublas -o result/build/moe_grouped_gemm_forward
// 可选 CUTLASS baseline：再加 -DUSE_CUTLASS -I "$CUTLASS_ROOT/include"
// ./result/build/moe_grouped_gemm_forward --m 2048 --experts 64 --n 512 --k 512 --dtype fp16
// 只实现前向专家 GEMM，不包含 router / top-k / token gather-scatter / gating。
// 输入已经按专家打包：A[sum(M_e), K], B[E,K,N], C[sum(M_e),N]。
// offsets 是行前缀和；同一个原始 token 的 top-k 副本视作不同的 packed row。
#include <memory>
#include <sstream>
#include "gemm_kernels.cuh"
#include "gemm_cutlass.cuh"

// ============================================================================
// 公共数据结构与 host 侧工具函数
// ============================================================================
// 类型: GroupTile
// 用途: 描述 grouped GEMM 的一个输出分块任务——(专家号 expert, 行块号 row, 列块号 col) 三元组。
//       所有基于 tile 表的 kernel(kernel3/4/6/7/8)都以它作为任务清单，host 侧预先剔除空专家/空 tile，
//       从而避免 kernel1 那种按专家整体 padding 造成的空转。
// 输入: 由 make_tiles / make_optimized_tiles / make_fixed_tiles / make_kernel8_tiles 在 host 侧生成。
// 输出: 上传到 device 后被内核只读，用于定位该 tile 在 A/B/C 中的地址偏移。
struct GroupTile {int expert,row,col;};
// 函数: make_counts
// 用途: 解析或构造每个专家的 token 数 counts[]。优先使用 --counts 字符串；
//       否则按 --distribution(balanced / skewed / empty)把总 M 划分到 experts 个专家上。
// 输入: GemmOptions o(o.counts 优先，否则用 o.experts / o.m / o.distribution)。
// 输出: std::vector<int> counts(长度 1..256，sum(counts) <= INT32_MAX)；
//       非法输入(空 count、专家数越界、和溢出等)抛 std::runtime_error。
inline std::vector<int> make_counts(const GemmOptions& o) {
    std::vector<int> counts;
    if(!o.counts.empty()) {
        std::istringstream s(o.counts);std::string v;
        if(o.counts.back()==',')throw std::runtime_error("empty count");
        while(std::getline(s,v,','))counts.push_back(gemm_integer(v.c_str(),0,INT32_MAX));
        if(counts.empty() || counts.size()>256)throw std::runtime_error("counts needs 1..256 experts");
    } else {
        counts.resize(o.experts);
        if(o.distribution=="empty")return counts;
        int start=0,remaining=o.m;
        if(o.distribution=="skewed") {counts[0]=int(int64_t(o.m)*3/4);remaining-=counts[0];start=1;}
        else if(o.distribution!="balanced")throw std::runtime_error("unknown distribution");
        if(start==o.experts)counts[0]=o.m;
        else for(int e=start;e<o.experts;++e)counts[e]+=remaining/(o.experts-start)+(e-start<remaining%(o.experts-start));
    }
    long long total=0;for(int m:counts)total+=m;
    if(total>INT32_MAX)throw std::runtime_error("sum(counts) exceeds INT32_MAX");
    return counts;
}

// 函数: make_tiles
// 用途: 为 kernel3 / kernel4 生成 tile 任务列表(按专家、按输出分块展开)。
// 输入: counts(各专家行数)、n(输出列数)、version(3 => 固定 16x16 分块；
//       4 => 小专家 M_e<=16 用 16x64、大专家用 64x64)。
// 输出: std::vector<GroupTile>，覆盖全部有效输出块；M_e=0 的专家不产生任务。
inline std::vector<GroupTile> make_tiles(const std::vector<int>& counts,int n,int version) {
    std::vector<GroupTile> tiles;
    for(int e=0;e<int(counts.size());++e) {
        // kernel4 对 <=16 tokens 的专家使用 BM=16，减少小专家的空算。
        int bm=version==3 ? 16 : (counts[e]<=16 ? 16 : 64),bn=version==3?16:64;
        for(int row=0;row<ceil_div(counts[e],bm);++row)
            for(int col=0;col<ceil_div(n,bn);++col)tiles.push_back({e,row,col});
    }
    return tiles;
}

// ============================================================================
// ------------------- kernel1 --------------------------
// 函数: moe_grouped_gemm_forward_kernel1<T>  [CUDA 内核]
// 用途: 最朴素的 grouped GEMM：一次 launch 覆盖全部专家，grid.z 维就是专家号，
//       直接调用每线程一个输出的 native(非分块)GEMM 内核。实现简单，
//       但小专家填不满线程块，padding 部分纯属浪费算力。
// 输入: c[sum(M_e), n] 输出缓冲；a[sum(M_e), k] 已按专家打包的激活；b[E, k, n] 各专家权重；
//       counts[E] 每专家行数；offsets[E] 行前缀和(各专家起始行)；n、k。
// 输出: 原地写回 c；无返回值。
// 启动配置: grid = (ceil(n/16), ceil(max_M_e/16), E)，block = (16, 16)。
// kernel1：一次 launch，grid.z 是 expert；小专家有被 padding 浪费的 block。
template<class T> __global__ void moe_grouped_gemm_forward_kernel1(
    T* c,
    const T* a,
    const T* b,
    const int* counts,
    const int* offsets,
    int n,
    int k
){
    int e=blockIdx.z,off=offsets[e];
    gemm_native_element(c+size_t(off)*n,a+size_t(off)*k,b+size_t(e)*k*n,
        counts[e],n,k,blockIdx.y*16+threadIdx.y,blockIdx.x*16+threadIdx.x);
}

// ------------------- kernel3 --------------------------
// 函数: moe_grouped_gemm_forward_kernel3<T>  [CUDA 内核]
// 用途: host 侧预先生成有效 tile 列表，用一个摊平的一维 grid 处理所有专家的所有 tile；
//       空专家、空 tile 根本不进入调度，消除 kernel1 的 padding 浪费；计算用 16x16 shared 分块。
// 输入: tiles[] 任务列表(见 make_tiles)；a / b / c / counts / offsets / n / k 同 kernel1。
// 输出: 原地写回 c；无返回值。
// 启动配置: grid = (tile 数)，block = (16, 16)。
// kernel3：host 预先生成有效 tile 列表，空专家没有 tile；各专家共享一个 grid。
template<class T> __global__ void moe_grouped_gemm_forward_kernel3(
    T* c,
    const T* a,
    const T* b,
    const int* counts,
    const int* offsets,
    const GroupTile* tiles,
    int n,
    int k
){
    __shared__ float sa[16][16],sb[16][16];
    auto t=tiles[blockIdx.x];int off=offsets[t.expert];
    gemm_shared_tile(c+size_t(off)*n,a+size_t(off)*k,b+size_t(t.expert)*k*n,
        counts[t.expert],n,k,t.row,t.col,sa,sb);
}

// ------------------- kernel4 --------------------------
// 函数: moe_grouped_gemm_forward_kernel4<T>  [CUDA 内核]
// 用途: 在 kernel3 的 tile 调度之上换成普通 GEMM 的寄存器分块：M_e<=16 的小专家用 16x64
//       分块以减少空算，大专家用 64x64 分块以提高数据复用。
// 输入: tiles[](由 make_tiles(version=4) 生成，分块大小已编码在 tile 中)、a / b / c / counts / offsets / n / k。
// 输出: 原地写回 c；无返回值。
// 启动配置: grid = (tile 数)，block = (16, 16)。
// kernel4：复用普通 GEMM 的寄存器分块；小专家使用 16x64，大专家使用 64x64。
template<class T> __global__ void moe_grouped_gemm_forward_kernel4(
    T* c,
    const T* a,
    const T* b,
    const int* counts,
    const int* offsets,
    const GroupTile* tiles,
    int n,
    int k
){
    __shared__ float sa[16][65],sb[16][64];
    auto t=tiles[blockIdx.x];int off=offsets[t.expert],m=counts[t.expert];
    if(m<=16)gemm_register_tile<T,16>(c+size_t(off)*n,a+size_t(off)*k,b+size_t(t.expert)*k*n,m,n,k,t.row,t.col,sa,sb);
    else gemm_register_tile<T,64>(c+size_t(off)*n,a+size_t(off)*k,b+size_t(t.expert)*k*n,m,n,k,t.row,t.col,sa,sb);
}


// ============================================================================
// ------------------- kernel6 --------------------------
// kernel6 系列：tile 表驱动 + 小专家矮分块(M_e<=16 用 BM=16)，消除小专家空算；
// 低精度(fp16/bf16)走 Tensor Core mma 路径，FP32 走 SIMT 寄存器分块路径。
// kernel6 只列出有效输出 tile。小专家使用较矮的 BM，空专家不参与调度。
// 函数: make_optimized_tiles<BM, BN, SMALL_BN>
// 用途: 为 kernel6 生成 tile 列表，只列有效输出 tile(空专家不参与调度)；
//       低精度模式下对 M_e<=16 的小专家使用更矮的 BM(默认 16x64)，进一步减少空算。
// 输入: counts(各专家行数)、n(输出列数)、low_precision(是否允许小专家特化)。
// 输出: std::vector<GroupTile>。
template<int BM=32,int BN=64,int SMALL_BN=64>
inline std::vector<GroupTile> make_optimized_tiles(
    const std::vector<int>& counts,
    int n,
    bool low_precision
){
    std::vector<GroupTile> tiles;
    for(int e=0;e<int(counts.size());++e) {
        bool small=low_precision && counts[e]<=16;
        int bm=small?16:BM,bn=small?SMALL_BN:BN;
        for(int row=0;row<ceil_div(counts[e],bm);++row)
            for(int col=0;col<ceil_div(n,bn);++col)tiles.push_back({e,row,col});
    }
    return tiles;
}

// 函数: moe_use_wide_tiles
// 用途: 依据实际 counts 判断是否启用宽 tile(BN=128)：当活跃专家数 > 1、存在较大专家(>=64 行)
//       且分布偏斜、同时 N 与 K 足够大时，加宽 BN 以提高 A 的复用率。
//       这是本轮扫参后得到的有限启发式，不保证覆盖所有 MoE 形状的最优配置。
// 输入: counts、n、k。
// 输出: bool，true 表示使用 BM=32 / BN=128 的加宽配置。
// 由实际 counts 选择，不依赖 --distribution 字符串。偏斜时扩大 BN，增加 A 复用。
// 这是本轮扫参后的有限启发式，不保证覆盖所有 MoE 形状的最优配置。
inline bool moe_use_wide_tiles(
    const std::vector<int>& counts,
    int n,
    int k
){
    int active=0,total=0,largest=0;
    for(int m:counts) {active+=m>0;total+=m;largest=std::max(largest,m);}
    return active>1 && largest>=64 && largest*2>total && n>=128 && k>=128;
}

// 函数: moe_copy_async_or_zero  [device 内联]
// 用途: 发出一次 16 字节的 cp.async 拷贝；当 valid=false 时把源长度设为 0，
//       由硬件直接补 16 字节零，从而统一对齐路径的边界处理、省掉分支，
//       并且无效源统一指向矩阵首地址，不构造越过 expert/分配范围的非法地址。
// 输入: destination(shared 目标地址)、source(global 源地址)、valid(该 8 元素 chunk 是否有效)。
// 输出: 无返回值；副作用是把异步拷贝入队(需配合 gemm_async_commit / gemm_async_wait)。
// 对齐路径中一个 chunk 恰好是 8 个 half/bf16。无效 chunk 由硬件补 16 字节零。
// 无效源使用矩阵首地址，不构造越过 expert/分配范围的读取地址。
__device__ __forceinline__ void moe_copy_async_or_zero(
    void* destination,
    const void* source,
    bool valid
){
    unsigned address=static_cast<unsigned>(__cvta_generic_to_shared(destination));
    int bytes=valid?16:0;
    asm volatile("cp.async.ca.shared.global [%0], [%1], 16, %2;"
        :: "r"(address),"l"(source),"r"(bytes) : "memory");
}
// 函数: moe_mma_load_tile<T, BM, BN, BK, PA, PB, ALIGNED>  [device 内联]
// 用途: 把一个 K 方向切片(base..base+BK)的 A 块(BM x BK)与 B 块(BK x BN)搬入 shared。
//       ALIGNED=true 走 cp.async 并在结尾 commit；否则逐元素标量拷贝，越界处填 0。
//       行越界(row>=m)或 K 越界(p>=k)一律补 0，保证 mma 结果不受 padding 干扰。
// 输入: a、b、m / n / k、row0 / col0(tile 全局起点)、base(K 切片起点)、sa / sb(shared 目标，列宽 PA / PB)。
// 输出: 填充 shared 数组 sa、sb；无返回值。
template<class T,int BM,int BN,int BK,int PA,int PB,bool ALIGNED>
__device__ __forceinline__ void moe_mma_load_tile(
    const T* a,
    const T* b,
    int m,
    int n,
    int k,
    int row0,
    int col0,
    int base,
    T (&sa)[BM][PA],
    T (&sb)[BK][PB]
){
    constexpr int THREADS=128;
    for(int index=threadIdx.x;index<BM*BK/8;index+=THREADS) {
        int row=row0+index/(BK/8),p=base+index%(BK/8)*8;
        T* destination=&sa[index/(BK/8)][gemm_mma_column<true>(index/(BK/8),index%(BK/8)*8)];
        if constexpr (ALIGNED) {
            bool valid=row<m && p<k;
            moe_copy_async_or_zero(destination,valid?a+size_t(row)*k+p:a,valid);
        } else {
            #pragma unroll
            for(int j=0;j<8;++j) destination[j]=(row<m && p+j<k)?a[size_t(row)*k+p+j]:from_float<T>(0.f);
        }
    }
    for(int index=threadIdx.x;index<BK*BN/8;index+=THREADS) {
        int p=base+index/(BN/8),col=col0+index%(BN/8)*8;
        T* destination=&sb[index/(BN/8)][gemm_mma_column<true>(index/(BN/8),index%(BN/8)*8)];
        if constexpr (ALIGNED) {
            bool valid=p<k && col<n;
            moe_copy_async_or_zero(destination,valid?b+size_t(p)*n+col:b,valid);
        } else {
            #pragma unroll
            for(int j=0;j<8;++j) destination[j]=(p<k && col+j<n)?b[size_t(p)*n+col+j]:from_float<T>(0.f);
        }
    }
    if constexpr (ALIGNED)gemm_async_commit();
}
// 函数: moe_store_pair<T>  [device 内联]
// 用途: 把 mma 累加器中两个相邻列的结果写回 C。n 为偶数且列未到边界时用向量化双元素写；
//       否则退化为标量写——因为 n 为奇数时不能假定下一行首地址仍满足 half2/bfloat162 的 4 字节对齐。
// 输入: c(输出基址)、row / col(全局坐标)、m / n(边界)、x / y(待写入的两个 float)。
// 输出: 写回 c；行或列越界时直接返回不写。
template<class T> __device__ __forceinline__ void moe_store_pair(
    T* c,
    int row,
    int col,
    int m,
    int n,
    float x,
    float y
){
    if(row>=m || col>=n)return;
    // n 为奇数时不能假定下一行首地址仍满足 half2/bfloat162 的 4-byte 对齐。
    if(n%2==0 && col+1<n)gemm_store2(c+size_t(row)*n+col,x,y);
    else {
        c[size_t(row)*n+col]=from_float<T>(x);
        if(col+1<n)c[size_t(row)*n+col+1]=from_float<T>(y);
    }
}

// 复用普通 GEMM kernel9 的 warp 原语；本函数增加任意 M/N/K 与安全的补零/写回。
// shared 从外层统一分配，两个 expert 分支复用同一块空间，不叠加 shared 占用。
// 函数: moe_mma_tile<T, BM, BN, BK, WM, WN, ALIGNED>  [device 内联]
// 用途: kernel6 低精度路径的单 tile 计算核心：2 级 K 缓冲 cp.async 搬运 + ldmatrix 取 fragment
//       + mma.16x8x16 累加 + 带边界保护的写回。shared 由调用方统一分配，
//       大小专家两个分支复用同一块空间，不叠加 shared 占用。
// 输入: c / a / b、m / n / k、row0 / col0(tile 起点)、storage(外部 shared，容纳 2 级 A/B 池)。
// 输出: 写回 C 中该 tile 的有效区域；无返回值。
template<class T,int BM,int BN,int BK,int WM,int WN,bool ALIGNED>
__device__ __forceinline__ void moe_mma_tile(
    T* c,
    const T* a,
    const T* b,
    int m,
    int n,
    int k,
    int row0,
    int col0,
    T* storage
){
    constexpr int PA=((BK+63)/64)*64,PB=((BN+63)/64)*64;
    auto& sa=*reinterpret_cast<T(*)[2][BM][PA]>(storage);
    auto& sb=*reinterpret_cast<T(*)[2][BK][PB]>(storage+2*BM*PA);
    int warp=threadIdx.x/32,lane=threadIdx.x&31;
    int warp_row=warp/(BN/WN)*WM,warp_col=warp%(BN/WN)*WN;
    float acc[WM/16][WN/8][4]={};
    unsigned ar[2][WM/16][4],br[2][WN/8][2];
    moe_mma_load_tile<T,BM,BN,BK,PA,PB,ALIGNED>(a,b,m,n,k,row0,col0,0,sa[0],sb[0]);
    if constexpr(ALIGNED)gemm_async_wait();
    __syncthreads();
    int pool=0;
    for(int base=0;base<k;base+=BK) {
        if(base+BK<k)moe_mma_load_tile<T,BM,BN,BK,PA,PB,ALIGNED>(a,b,m,n,k,row0,col0,base+BK,sa[pool^1],sb[pool^1]);
        gemm_mma_load_fragments<T,BM,BN,BK,WM,WN,PA,PB,true>(ar[0],br[0],sa[pool],sb[pool],warp_row,warp_col,0);
        #pragma unroll
        for(int p=0;p<BK;p+=16) {
            int current=(p/16)&1;
            if(p+16<BK)gemm_mma_load_fragments<T,BM,BN,BK,WM,WN,PA,PB,true>(ar[current^1],br[current^1],sa[pool],sb[pool],warp_row,warp_col,p+16);
            #pragma unroll
            for(int i=0;i<WM/16;++i) {
                #pragma unroll
                for(int j=0;j<WN/8;++j)gemm_mma_16x8x16<T>(acc[i][j],ar[current][i],br[current][j]);
            }
        }
        if(base+BK<k) {
            if constexpr(ALIGNED)gemm_async_wait();
            __syncthreads();pool^=1;
        }
    }
    #pragma unroll
    for(int i=0;i<WM/16;++i) {
        #pragma unroll
        for(int j=0;j<WN/8;++j) {
            int row=row0+warp_row+i*16+lane/4,col=col0+warp_col+j*8+(lane%4)*2;
            moe_store_pair(c,row,col,m,n,acc[i][j][0],acc[i][j][1]);
            moe_store_pair(c,row+8,col,m,n,acc[i][j][2],acc[i][j][3]);
        }
    }
}

// ------------------- kernel6-mma --------------------------
// 函数: moe_grouped_gemm_forward_kernel6_mma<T, BM, BN, WM, WN, SMALL_BN, BK, PERSISTENT>  [CUDA 内核]
// 用途: kernel6 的低精度(fp16/bf16)Tensor Core 主内核。一个 launch 处理全部 tile；
//       同一 CTA 内的专家分支一致，因此不会出现跨分支的 divergent barrier。
//       默认小专家 16x64、大专家 32x64；偏斜场景通过模板参数加宽 BN；所有配置均为 4 warps。
//       PERSISTENT=true 时用 grid-stride 复用 CTA(供调参对比，不引入全局 atomic 队列)。
// 输入: c / a / b、counts、offsets、tiles(任务表)、tile_count、n、k。
// 输出: 原地写回 c；无返回值。
// 启动配置: grid = (tile 数)，block = (128)；shared = max(2*(BM*PA+BK*PB), 2*(16*PA+BK*SMALL_PB)) 个 T。
// kernel6 low precision：一个 launch，CTA 内的 expert 分支一致，不存在分歧 barrier。
// 默认小专家 16x64，大专家 32x64；偏斜场景扩大 BN，所有配置均为 4 warps。
// PERSISTENT 用 grid-stride 分配 tile，供调参比较，不引入全局 atomic 队列。
template<class T,int BM=32,int BN=64,int WM=16,int WN=32,int SMALL_BN=64,int BK=32,bool PERSISTENT=false>
__global__ void moe_grouped_gemm_forward_kernel6_mma(
    T* __restrict__ c,
    const T* __restrict__ a,
    const T* __restrict__ b,
    const int* counts,
    const int* offsets,
    const GroupTile* tiles,
    int tile_count,
    int n,
    int k
){
    static_assert(!std::is_same_v<T,float> && (BM/WM)*(BN/WN)==4 && SMALL_BN%32==0,"invalid grouped MMA shape");
    constexpr int PA=((BK+63)/64)*64,PB=((BN+63)/64)*64,SMALL_PB=((SMALL_BN+63)/64)*64;
    constexpr int LARGE=2*(BM*PA+BK*PB),SMALL=2*(16*PA+BK*SMALL_PB);
    __shared__ __align__(16) T storage[LARGE>SMALL?LARGE:SMALL];
    for(int index=blockIdx.x;index<tile_count;index+=gridDim.x) {
        auto t=tiles[index];int off=offsets[t.expert],m=counts[t.expert];
        T* ce=c+size_t(off)*n;
        const T* ae=a+size_t(off)*k;
        const T* be=b+size_t(t.expert)*k*n;
        bool aligned=n%8==0 && k%8==0;
        if(m<=16) {
            if(aligned)moe_mma_tile<T,16,SMALL_BN,BK,16,SMALL_BN/4,true>(ce,ae,be,m,n,k,t.row*16,t.col*SMALL_BN,storage);
            else moe_mma_tile<T,16,SMALL_BN,BK,16,SMALL_BN/4,false>(ce,ae,be,m,n,k,t.row*16,t.col*SMALL_BN,storage);
        } else {
            if(aligned)moe_mma_tile<T,BM,BN,BK,WM,WN,true>(ce,ae,be,m,n,k,t.row*BM,t.col*BN,storage);
            else moe_mma_tile<T,BM,BN,BK,WM,WN,false>(ce,ae,be,m,n,k,t.row*BM,t.col*BN,storage);
        }
        if constexpr(PERSISTENT)__syncthreads(); // 所有旧 tile 消费者读完，才能复用输入池。
        else break;
    }
}

// 函数: moe_simt_prefetch<BM, BN, BK, THREADS>  [device 内联]
// 用途: kernel6 FP32 路径的 global -> register 预取：把下一个 K 切片的 A(BM x BK) 与 B(BK x BN)
//       以 float4 读入寄存器。K/N 非 4 对齐或尾块时逐元素取值并补 0，不向邻居专家越界读取。
// 输入: a、b、m / n / k、row0 / col0(tile 起点)、base(下一个 K 切片起点)、av / bv(寄存器缓冲区)。
// 输出: 填充 av[]、bv[]；无返回值。
// FP32 路径：向量化、shared XOR、global 预取双池与 register 操作数双缓冲。
// 不降低输入精度。非对齐/尾块用标量读写，不向邻居专家越界读取。
template<int BM=32,int BN=64,int BK=16,int THREADS=128>
__device__ __forceinline__ void moe_simt_prefetch(
    const float* a,
    const float* b,
    int m,
    int n,
    int k,
    int row0,
    int col0,
    int base,
    float4* av,
    float4* bv
){
    #pragma unroll
    for(int v=0;v<BM*BK/4/THREADS;++v) {
        int index=threadIdx.x+v*THREADS,row=row0+index/(BK/4),p=base+index%(BK/4)*4;
        float4 value=make_float4(0.f,0.f,0.f,0.f);
        if(row<m) {
            if(k%4==0 && p+3<k)value=*reinterpret_cast<const float4*>(a+size_t(row)*k+p);
            else {
                #pragma unroll
                for(int j=0;j<4;++j)if(p+j<k)(&value.x)[j]=a[size_t(row)*k+p+j];
            }
        }
        av[v]=value;
    }
    #pragma unroll
    for(int v=0;v<BK*BN/4/THREADS;++v) {
        int index=threadIdx.x+v*THREADS,p=base+index/(BN/4),col=col0+index%(BN/4)*4;
        float4 value=make_float4(0.f,0.f,0.f,0.f);
        if(p<k) {
            if(n%4==0 && col+3<n)value=*reinterpret_cast<const float4*>(b+size_t(p)*n+col);
            else {
                #pragma unroll
                for(int j=0;j<4;++j)if(col+j<n)(&value.x)[j]=b[size_t(p)*n+col+j];
            }
        }
        bv[v]=value;
    }
}
// ------------------- kernel6-fp32 --------------------------
// 函数: moe_grouped_gemm_forward_kernel6_fp32  [CUDA 内核]
// 用途: kernel6 的 FP32 精度路径(不降低输入精度)：向量化访存 + shared XOR 交换避免 bank conflict
//       + global 预取双池 + 寄存器操作数双缓冲的 SIMT 分块 GEMM(32x64，每线程 4x4 累加)。
//       非对齐/尾块使用标量读写，不越界。
// 输入: c / a / b(均为 float)、counts、offsets、tiles、n、k。
// 输出: 原地写回 c；无返回值。
// 启动配置: grid = (tile 数)，block = (128)。
__global__ void moe_grouped_gemm_forward_kernel6_fp32(
    float* __restrict__ c,
    const float* __restrict__ a,
    const float* __restrict__ b,
    const int* counts,
    const int* offsets,
    const GroupTile* tiles,
    int n,
    int k
){
    constexpr int BM=32,BN=64,BK=16,TM=4,TN=4,THREADS=128;
    __shared__ __align__(16) float sa[2][BK][BM],sb[2][BK][BN];
    auto t=tiles[blockIdx.x];int off=offsets[t.expert],m=counts[t.expert];
    const float* ae=a+size_t(off)*k;
    const float* be=b+size_t(t.expert)*k*n;
    float* ce=c+size_t(off)*n;
    int row0=t.row*BM,col0=t.col*BN,y=threadIdx.x/(BN/TN),x=threadIdx.x%(BN/TN);
    float acc[TM][TN]={};
    float4 next_a[BM*BK/4/THREADS],next_b[BK*BN/4/THREADS];
    moe_simt_prefetch(ae,be,m,n,k,row0,col0,0,next_a,next_b);
    gemm_publish_tile<BM,BN,BK,THREADS>(next_a,next_b,sa[0],sb[0]);__syncthreads();
    int pool=0;
    for(int base=0;base<k;base+=BK) {
        if(base+BK<k)moe_simt_prefetch(ae,be,m,n,k,row0,col0,base+BK,next_a,next_b);
        float4 ar[2][1],br[2][1];
        gemm_simt_load_fragments<BM,BN,BK,TM,TN>(ar[0],br[0],sa[pool],sb[pool],y,x,0);
        #pragma unroll
        for(int p=0;p<BK;++p) {
            int current=p&1;
            if(p+1<BK)gemm_simt_load_fragments<BM,BN,BK,TM,TN>(ar[current^1],br[current^1],sa[pool],sb[pool],y,x,p+1);
            #pragma unroll
            for(int i=0;i<TM;++i) {
                #pragma unroll
                for(int j=0;j<TN;++j)acc[i][j]=fmaf((&ar[current][0].x)[i],(&br[current][0].x)[j],acc[i][j]);
            }
        }
        if(base+BK<k) {gemm_publish_tile<BM,BN,BK,THREADS>(next_a,next_b,sa[pool^1],sb[pool^1]);__syncthreads();pool^=1;}
    }
    #pragma unroll
    for(int i=0;i<TM;++i) {
        int row=row0+y*4+i,col=col0+x*4;
        if(row<m) {
            if(n%4==0 && col+3<n)gemm_store4(ce+size_t(row)*n+col,make_float4(acc[i][0],acc[i][1],acc[i][2],acc[i][3]));
            else {
                #pragma unroll
                for(int j=0;j<TN;++j)if(col+j<n)ce[size_t(row)*n+col+j]=acc[i][j];
            }
        }
    }
}

// ============================================================================
// ------------------- kernel7/8-shared-core --------------------------
// kernel7 / kernel8：共用固定 N=K=1024 的 Tensor Core 计算核心，只列出有效输出 tile。
// 下面的谓词与 tile 生成函数决定命中哪条特化路径。
// kernel7：固定 counts=[64,96,160,192]x4、FP16、N=K=1024。
// BM/BN/BK=32/128/32，warp=32x32，三层 shared 流水线；所有 M_e 都整除 BM。
// 函数: moe_is_fixed_target
// 用途: 判断当前问题是否命中 kernel7 的特化形状——E=16、counts 恰为 [64,96,160,192]x4、
//       N=K=1024(此时所有 M_e 都能整除 BM=32，没有尾块，可用最激进的快路径)。
// 输入: counts、n、k。
// 输出: bool，true 表示可直接走 kernel7 的固定形状内核。
inline bool moe_is_fixed_target(const std::vector<int>& counts,int n,int k) {
    constexpr int pattern[]={64,96,160,192};
    if(counts.size()!=16 || n!=1024 || k!=1024)return false;
    for(int e=0;e<16;++e)if(counts[e]!=pattern[e%4])return false;
    return true;
}
// 函数: make_fixed_tiles
// 用途: 为 kernel7 生成 tile 列表。同一专家、同一 N tile 的多个 M tile 在列表中相邻，
//       以提高 B 在 L2 中的复用机会(固定形状下无尾块，M 方向正好整除)。
// 输入: counts(需满足 moe_is_fixed_target)。
// 输出: std::vector<GroupTile>，顺序为 expert -> N tile -> M tile。
inline std::vector<GroupTile> make_fixed_tiles(const std::vector<int>& counts) {
    std::vector<GroupTile> tiles;
    // 同一专家、同一 N tile 的 M tiles 相邻，增加 B 在 L2 中的复用机会。
    for(int e=0;e<int(counts.size());++e)
        for(int col=0;col<1024/128;++col)
            for(int row=0;row<counts[e]/32;++row)tiles.push_back({e,row,col});
    return tiles;
}
// kernel8：固定 E=16、sum(M_e)=2048、N=K=1024；每个专家的 M_e 可以为零或任意尾块。
// 函数: moe_is_kernel8_target
// 用途: 判断是否命中 kernel8 的目标形状——E=16、sum(M_e)=2048、N=K=1024，
//       每个专家的 M_e 可以为零或任意尾块(与 kernel7 的固定 counts 相对)。
// 输入: counts、n、k。
// 输出: bool。
inline bool moe_is_kernel8_target(const std::vector<int>& counts,int n,int k) {
    if(counts.size()!=16 || n!=1024 || k!=1024)return false;
    int total=0;for(int m:counts)total+=m;
    return total==2048;
}
// 函数: make_kernel8_tiles
// 用途: 为 kernel8 生成 tile 列表。M 方向向上取整以覆盖尾块；M_e=0 的专家自然不会产生任务。
// 输入: counts。
// 输出: std::vector<GroupTile>，顺序为 expert -> N tile -> M tile。
inline std::vector<GroupTile> make_kernel8_tiles(const std::vector<int>& counts) {
    std::vector<GroupTile> tiles;
    // 保持专家/N/M 次序；向上取整覆盖尾块，M_e=0 自然不会产生任务。
    for(int e=0;e<int(counts.size());++e)
        for(int col=0;col<1024/128;++col)
            for(int row=0;row<ceil_div(counts[e],32);++row)tiles.push_back({e,row,col});
    return tiles;
}
// 函数: moe_compact_shared_index<WIDTH>  [device 内联]
// 用途: 对共享内存中线性排列的 half/bf16 下标做 XOR 重映射：BK=32 时交换物理行，
//       省掉 PA=64 的 padding，同时消除 bank conflict。
//       低 3 位保持不变，因此 16 字节 cp.async 与 ldmatrix 访存依旧对齐、连续；读写共用同一映射。
// 输入: row(行)、col(列)；模板参数 WIDTH 为 shared 行宽(BK 或 BN)。
// 输出: int，重映射后的线性下标。
// 对线性 half 地址做 XOR：BK=32 时交换物理行，省掉 PA=64 的 padding。
// 低三位不变，16-byte cp.async 保持对齐、连续；读写使用同一个地址映射。
template<int WIDTH>
__device__ __forceinline__ int moe_compact_shared_index(int row,int col) {
    return (row*WIDTH+col)^((row&7)*8);
}
// 函数: moe_fixed_copy<T, BM, BN, BK, N, K>  [device 内联]
// 用途: kernel7/8 固定形状下的一个 stage 拷贝：A 块用 cp.async(带越界补零)按 XOR 映射写入 shared，
//       B 块用 gemm_copy_async16 整块异步拷贝，最后统一 commit。
//       N/K 是编译期常量，地址计算可以完全常量折叠。
// 输入: a / b、m(该专家行数)、row0 / col0(tile 起点)、base(K 切片起点)、sa / sb(shared 目标)。
// 输出: 填充 sa / sb 并提交异步拷贝；无返回值。
template<class T,int BM,int BN,int BK,int N=1024,int K=1024>
__device__ __forceinline__ void moe_fixed_copy(
    const T* a,const T* b,int m,int row0,int col0,int base,T* sa,T* sb
){
    for(int index=threadIdx.x;index<BM*BK/8;index+=128) {
        int row=index/(BK/8),p=index%(BK/8)*8;
        bool valid=row0+row<m;
        moe_copy_async_or_zero(sa+moe_compact_shared_index<BK>(row,p),valid?a+size_t(row0+row)*K+base+p:a,valid);
    }
    for(int index=threadIdx.x;index<BK*BN/8;index+=128) {
        int p=index/(BN/8),col=index%(BN/8)*8;
        gemm_copy_async16(sb+moe_compact_shared_index<BN>(p,col),b+size_t(base+p)*N+col0+col);
    }
    gemm_async_commit();
}
// 函数: moe_fixed_fragments<T, BM, BN, BK, WM, WN>  [device 内联]
// 用途: 用 ldmatrix 从 shared 中取出一个 K 片段(p..p+16)的 A/B fragment；
//       B 侧用一条 ldmatrix.x4.trans 同时读取相邻两个 16x8 fragment，减少 ldmatrix 指令数。
// 输入: sa / sb(shared)、wr / wc(本 warp 在 tile 内的起点)、p(K 片段在 tile 内的偏移)。
// 输出: 填充寄存器操作数 ar[WM/16][4] 与 br[WN/8][2]；无返回值。
template<class T,int BM,int BN,int BK,int WM,int WN>
__device__ __forceinline__ void moe_fixed_fragments(
    unsigned (&ar)[WM/16][4],unsigned (&br)[WN/8][2],
    const T* sa,const T* sb,int wr,int wc,int p
){
    int lane=threadIdx.x&31;
    #pragma unroll
    for(int i=0;i<WM/16;++i)
        gemm_ldmatrix_a(ar[i],sa+moe_compact_shared_index<BK>(wr+i*16+(lane&15),p+(lane/16)*8));
    #pragma unroll
    for(int j=0;j<WN/8;j+=2) {
        // 一条 x4.trans 读取两个相邻的 16x8 B fragment，减少 ldmatrix 指令。
        unsigned x[4];unsigned address=static_cast<unsigned>(__cvta_generic_to_shared(
            sb+moe_compact_shared_index<BN>(p+(lane&15),wc+j*8+(lane/16)*8)));
        asm volatile("ldmatrix.sync.aligned.m8n8.x4.trans.shared.b16 {%0,%1,%2,%3}, [%4];"
            :"=r"(x[0]),"=r"(x[1]),"=r"(x[2]),"=r"(x[3]):"r"(address));
        br[j][0]=x[0];br[j][1]=x[1];br[j+1][0]=x[2];br[j+1][1]=x[3];
    }
}

// 函数: moe_fixed_wait<GROUPS>  [device 内联]
// 用途: 封装 cp.async.wait_group，等待到在途拷贝组数 <= GROUPS，用于多级软流水的同步。
//       收尾时必须排空(没有新提交时 wait_group 1 可能留下最后一块未完成)。
// 输入: 模板参数 GROUPS(允许继续在途的拷贝组数)。
// 输出: 无返回值(仅同步语义)。
template<int GROUPS>
__device__ __forceinline__ void moe_fixed_wait() {
    asm volatile("cp.async.wait_group %0;" :: "n"(GROUPS) : "memory");
}
// 函数: moe_tile_store2<Out>  [device 内联]
// 用途: 把两个相邻列的结果按输出类型写回：Out=float 时写 float2(用于 Split-K 的 FP32 partial，
//       避免中间结果被提前舍入)，否则走 gemm_store2 写 half2 / bfloat162。
// 输入: c(目标地址)、x / y(待写值)。
// 输出: 写回 c；无返回值。
template<class Out> __device__ __forceinline__ void moe_tile_store2(Out* c,float x,float y) {
    if constexpr(std::is_same_v<Out,float>)*reinterpret_cast<float2*>(c)=make_float2(x,y);
    else gemm_store2(c,x,y);
}
// 函数: moe_fixed_tile<T, BM, BN, BK, WM, WN, STAGES, N, K, Out>  [device 内联]
// 用途: kernel7 / kernel8 / kernel9 共用的固定 N/K 计算核心：STAGES(2~4)级 cp.async 软流水
//       + ldmatrix 取 fragment + mma.16x8x16 累加 + 带行边界屏蔽的写回。
//       first_tile / last_tile 允许只计算一段 K tile，从而支持 Split-K。
// 输入: c(输出基址，元素类型 Out 可为 T 或 float)、a / b、m(该专家行数)、row0 / col0(tile 起点)、
//       storage(外部 shared，需 STAGES*(BM*BK + BK*BN) 个元素)、first_tile / last_tile(K tile 区间)。
// 输出: 写回 c 中该 tile 的有效行；无返回值。
template<class T,int BM,int BN,int BK,int WM,int WN,int STAGES,int N=1024,int K=1024,class Out=T>
__device__ __forceinline__ void moe_fixed_tile(
    Out* c,
    const T* a,
    const T* b,
    int m,
    int row0,
    int col0,
    T* storage,
    int first_tile=0,
    int last_tile=K/BK
){
    constexpr int PA=BK,PB=BN,TILES=K/BK;
    static_assert(STAGES>=2 && STAGES<=4 && K%BK==0 && N%BN==0);
    auto& sa=*reinterpret_cast<T(*)[STAGES][BM][PA]>(storage);
    auto& sb=*reinterpret_cast<T(*)[STAGES][BK][PB]>(storage+STAGES*BM*PA);
    int warp=threadIdx.x/32,lane=threadIdx.x&31;
    int wr=warp/(BN/WN)*WM,wc=warp%(BN/WN)*WN;
    float acc[WM/16][WN/8][4]={};
    unsigned ar[WM/16][4],br[WN/8][2];
    // 预填 STAGES-1 块，等待第一块，保留最新一组拷贝在途。
    #pragma unroll
    for(int stage=0;stage<STAGES-1;++stage)
        moe_fixed_copy<T,BM,BN,BK,N,K>(a,b,m,row0,col0,(first_tile+stage)*BK,&sa[stage][0][0],&sb[stage][0][0]);
    moe_fixed_wait<STAGES-2>();__syncthreads();
    int pool=0;
    for(int tile=first_tile;tile<last_tile;++tile) {
        int next=tile+STAGES-1,copy_pool=pool?pool-1:STAGES-1;
        if(next<last_tile)
            moe_fixed_copy<T,BM,BN,BK,N,K>(a,b,m,row0,col0,next*BK,&sa[copy_pool][0][0],&sb[copy_pool][0][0]);
        // 此 warp 分块实测单组操作数寄存器更快。
        #pragma unroll
        for(int p=0;p<BK;p+=16) {
            moe_fixed_fragments<T,BM,BN,BK,WM,WN>(ar,br,&sa[pool][0][0],&sb[pool][0][0],wr,wc,p);
            #pragma unroll
            for(int i=0;i<WM/16;++i) {
                #pragma unroll
                for(int j=0;j<WN/8;++j)gemm_mma_16x8x16<T>(acc[i][j],ar[i],br[j]);
            }
        }
        if(tile+1<last_tile) {
            // 收尾必须排空：没有新提交时 wait_group 1 可能留下最后一块未完成。
            if(next<last_tile)moe_fixed_wait<STAGES-2>();
            else moe_fixed_wait<0>();
            __syncthreads();
        }
        if(++pool==STAGES)pool=0;
    }
    #pragma unroll
    for(int i=0;i<WM/16;++i) {
        #pragma unroll
        for(int j=0;j<WN/8;++j) {
            int row=row0+wr+i*16+lane/4,col=col0+wc+j*8+(lane%4)*2;
            if(row<m)moe_tile_store2(c+size_t(row)*N+col,acc[i][j][0],acc[i][j][1]);
            if(row+8<m)moe_tile_store2(c+size_t(row+8)*N+col,acc[i][j][2],acc[i][j][3]);
        }
    }
}
// ------------------- kernel7 --------------------------
// 函数: moe_grouped_gemm_forward_kernel7  [CUDA 内核]
// 用途: FP16 固定形状特化内核(E=16，counts=[64,96,160,192]x4，N=K=1024，无尾块)：
//       直接按 tile 表调度，内部固定 32x128x32 分块、warp 32x32、3 级 shared 软流水。
// 输入: c / a / b(half)、counts、offsets、tiles(由 make_fixed_tiles 生成)。
// 输出: 原地写回 c；无返回值。
// 启动配置: grid = (tile 数)，block = (128)，动态 shared = 3*(32*32 + 32*128)*sizeof(half)。
// 最终保留 32x128x32 / warp 32x32 / 3 stages；其他候选留在实验记录。
__global__ void moe_grouped_gemm_forward_kernel7(
    half* __restrict__ c,
    const half* __restrict__ a,
    const half* __restrict__ b,
    const int* counts,
    const int* offsets,
    const GroupTile* tiles
){
    extern __shared__ __align__(16) unsigned char storage[];
    auto t=tiles[blockIdx.x];int off=offsets[t.expert];
    moe_fixed_tile<half,32,128,32,32,32,3>(c+size_t(off)*1024,a+size_t(off)*1024,
        b+size_t(t.expert)*1024*1024,counts[t.expert],t.row*32,t.col*128,reinterpret_cast<half*>(storage));
}

// ------------------- kernel8 --------------------------
// 函数: moe_grouped_gemm_forward_kernel8  [CUDA 内核]
// 用途: 复用 kernel7 的固定 N/K 计算核心，但允许每个专家的 M_e 为零或带任意尾块
//       (依赖 A 加载补零与输出行屏蔽)，用于 E=16、sum(M_e)=2048 的可变 counts 场景。
// 输入: c / a / b(half)、counts、offsets、tiles(由 make_kernel8_tiles 生成)。
// 输出: 原地写回 c；无返回值。
// 启动配置: grid = (tile 数)，block = (128)，动态 shared 同 kernel7。
// 复用 kernel7 的固定 N/K 计算核心；其 A 加载补零和输出行屏蔽支持任意 M 尾块。
__global__ void moe_grouped_gemm_forward_kernel8(
    half* __restrict__ c,
    const half* __restrict__ a,
    const half* __restrict__ b,
    const int* counts,
    const int* offsets,
    const GroupTile* tiles
){
    extern __shared__ __align__(16) unsigned char storage[];
    auto t=tiles[blockIdx.x];int off=offsets[t.expert];
    moe_fixed_tile<half,32,128,32,32,32,3>(c+size_t(off)*1024,a+size_t(off)*1024,
        b+size_t(t.expert)*1024*1024,counts[t.expert],t.row*32,t.col*128,reinterpret_cast<half*>(storage));
}

// ============================================================================
// ------------------- kernel9 --------------------------
// kernel9 系列：在 GPU 上根据 counts 现场计算 offsets / tile 前缀(元数据)，不回读 CPU；
// 主内核用固定形状计算核心 + 可复用 CTA 调度全部 tile；小 M 场景支持 K 方向 Split-K，
// 先写 FP32 partial，最后由 reduce 内核统一归约并只做一次舍入。
// kernel9：GPU counts -> offsets/Tile 前缀；不把动态专家分配读回 CPU。
// 上限为首版 E<=16；64-bit 地址和前缀，M 的 API 范围为 0..INT32_MAX。
// 类型: GroupedMetadata9
// 用途: kernel9 的 GPU 侧元数据。offsets[17] 是各专家行位移的前缀和，tiles[17] 是 tile 数前缀和，
//       valid 标记元数据是否自洽(非法时各内核直接返回，绝不触发矩阵访问)。上限为 E<=16。
// 输入: 由 moe_grouped_prepare_kernel9 在 GPU 上填充。
// 输出: 被 kernel9 主内核 / split-K 内核 / reduce 内核只读使用。
struct GroupedMetadata9 {int64_t offsets[17],tiles[17];int valid;};
// ------------------- kernel9-prepare --------------------------
// 函数: moe_grouped_prepare_kernel9  [CUDA 内核]
// 用途: 把 counts 转成 offsets 与 tile 前缀和，避免把动态专家分配读回 CPU；
//       同时校验 0 <= counts[e] <= m 且 sum(counts) == m，不满足则置 meta->valid=0。
// 输入: counts[experts](int64)、experts、m(总行数)、bm(当前 config 的 M 分块)、n(输出列数，用于算 N tile 数)。
// 输出: 写 meta->offsets[]、meta->tiles[]、meta->valid；无返回值。
// 启动配置: grid = (1)，block = (32)，仅 threadIdx.x==0 执行。
__global__ void moe_grouped_prepare_kernel9(
    GroupedMetadata9* meta,const int64_t* counts,int experts,int m,int bm,int n
) {
    if(threadIdx.x)return;
    meta->offsets[0]=meta->tiles[0]=0;meta->valid=1;
    for(int e=0;e<experts;++e) {
        int64_t rows=counts[e];
        if(rows<0 || rows>m) {meta->valid=0;rows=0;}
        meta->offsets[e+1]=meta->offsets[e]+rows;
        meta->tiles[e+1]=meta->tiles[e]+((rows+bm-1)/bm)*(n/128);
    }
    if(meta->offsets[experts]!=m)meta->valid=0;
}
// ------------------- kernel9-gemm --------------------------
// 函数: moe_grouped_gemm_forward_kernel9<T, N, K, BM, WM, WN, STAGES>  [CUDA 内核]
// 用途: kernel9 的主计算内核。用前缀和线性扫描定位每个 task 属于哪个专家(自动跳过空专家)，
//       再调用固定形状的 moe_fixed_tile 计算该 tile；当 grid 小于 tile 总数时，CTA 以 grid-stride
//       方式复用(persistent 候选)，复用 shared 前用 __syncthreads 保证上一任务已消费完。
// 输入: c / a / b、meta(offsets / tiles / valid)、experts。
// 输出: 原地写回 c；meta->valid=0 时立即返回。
// 启动配置: grid = 容量上界(可由 blocks 限制)，block = (128)，动态 shared = STAGES*(BM+128)*32*sizeof(T)。
template<class T,int N,int K,int BM,int WM,int WN,int STAGES>
__global__ void moe_grouped_gemm_forward_kernel9(
    T* __restrict__ c,const T* __restrict__ a,const T* __restrict__ b,
    const GroupedMetadata9* meta,int experts
) {
    extern __shared__ __align__(16) unsigned char storage[];
    if(!meta->valid)return; // CTA 内一致；非法元数据不会触发矩阵访问。
    int64_t total=meta->tiles[experts];
    // grid=capacity 是单 Tile/CTA；限制 grid 后复用 CTA，即 persistent 候选。
    for(int64_t task=blockIdx.x;task<total;task+=gridDim.x) {
        int e=0;while(task>=meta->tiles[e+1])++e; // 跳过空专家的重复前缀。
        int64_t off=meta->offsets[e],rows=meta->offsets[e+1]-off;
        int64_t row_tiles=(rows+BM-1)/BM,local=task-meta->tiles[e];
        int row=int(local%row_tiles)*BM,col=int(local/row_tiles)*128;
        moe_fixed_tile<T,BM,128,32,WM,WN,STAGES,N,K>(c+size_t(off)*N,a+size_t(off)*K,
            b+size_t(e)*K*N,int(rows),row,col,reinterpret_cast<T*>(storage));
        // 下一任务覆写共享内存前，确保所有 warp 已消费完本次数据。
        if(gridDim.x<total)__syncthreads();
    }
}
// 函数: moe_is_kernel9_target
// 用途: 判断 (experts, n, k) 是否落在 kernel9 已经实例化的形状集合内：
//       E 在 1..16，且 (N,K) 为 (2432,768) / (768,2432) / (1024,1024) 之一。
// 输入: experts、n、k。
// 输出: bool，true 表示 kernel9 支持该 shape。
inline bool moe_is_kernel9_target(int experts,int n,int k) {
    return experts>=1 && experts<=16 &&
        ((n==2432 && k==768)||(n==768 && k==2432)||(n==1024 && k==1024));
}
// ------------------- kernel9-split-k --------------------------
// 函数: moe_grouped_split_kernel9<T, N, K>  [CUDA 内核]
// 用途: 小 M 场景的 Split-K 第一段：把 K 方向切成 parts 段(blockIdx.z 选择段号)，
//       用 BM=16 的 moe_fixed_tile 只算出 FP32 partial(不舍入)，交由 reduce 内核合并。
// 输入: partial[parts, m, N] 输出缓冲、a / b、meta、experts、m(总行数)、parts(切分段数)。
// 输出: 写 partial(FP32)；无返回值。
// 启动配置: grid = (grid, 1, parts)，block = (128)，动态 shared = 3*(16+128)*32*sizeof(T)。
// 小 M 追加 Split-K：先写 FP32 partial，最后一次性舍入为输出类型。
template<class T,int N,int K> __global__ void moe_grouped_split_kernel9(
    float* partial,const T* a,const T* b,const GroupedMetadata9* meta,int experts,int m,int parts
) {
    extern __shared__ __align__(16) unsigned char storage[];
    if(!meta->valid)return;
    int chunk=(K/32+parts-1)/parts,first=blockIdx.z*chunk,last=min(K/32,first+chunk);
    int64_t total=meta->tiles[experts];
    for(int64_t task=blockIdx.x;task<total;task+=gridDim.x) {
        int e=0;while(task>=meta->tiles[e+1])++e;
        int64_t off=meta->offsets[e],rows=meta->offsets[e+1]-off;
        int64_t row_tiles=(rows+15)/16,local=task-meta->tiles[e];
        moe_fixed_tile<T,16,128,32,16,32,3,N,K,float>(
            partial+(size_t(blockIdx.z)*m+off)*N,a+size_t(off)*K,b+size_t(e)*K*N,
            int(rows),int(local%row_tiles)*16,int(local/row_tiles)*128,
            reinterpret_cast<T*>(storage),first,last);
        if(gridDim.x<total)__syncthreads();
    }
}
// ------------------- kernel9-reduce --------------------------
// 函数: moe_grouped_reduce_kernel9<T>  [CUDA 内核]
// 用途: Split-K 第二段：把 parts 份 FP32 partial 按元素累加，最后统一转换成输出类型写回，
//       保证整个归约过程只进行一次舍入。
// 输入: c(输出，类型 T)、partial[parts, elements]、meta、elements(= m*N)、parts。
// 输出: 写回 c；meta->valid=0 或下标越界时直接返回。
// 启动配置: grid = (ceil_div(m*N, 256))，block = (128)，每线程处理 2 个相邻元素。
template<class T> __global__ void moe_grouped_reduce_kernel9(
    T* c,const float* partial,const GroupedMetadata9* meta,int64_t elements,int parts
) {
    if(!meta->valid)return;
    int64_t index=(int64_t(blockIdx.x)*128+threadIdx.x)*2;
    if(index>=elements)return;
    float x=0,y=0;
    for(int p=0;p<parts;++p) {
        float2 value=*reinterpret_cast<const float2*>(partial+int64_t(p)*elements+index);
        x+=value.x;y+=value.y;
    }
    gemm_store2(c+index,x,y);
}
// 函数: moe_kernel9_bm
// 用途: 由 config 反推该配置使用的 M 分块 BM(与 moe_launch_kernel9_shape 的 switch 保持一致)，
//       供 host 侧估算 tile 容量上界以及 prepare 内核使用。
// 输入: config(0..7)。
// 输出: int，BM 取值为 16 / 32 / 64。
inline int moe_kernel9_bm(int config) {return config>=6?16:config%3==0?32:config%3==1?16:64;}
// 函数: moe_kernel9_default_config
// 用途: kernel9 的默认选路启发式：只依据 host 已知的 (m, n, k) 选择 config，
//       不读取 GPU 上的 counts(因此不引入 device->host 同步)。这是本轮有限扫参得到的经验规则。
// 输入: m(总行数)、n、k。
// 输出: int，config 编号 0..7(>=6 表示启用 Split-K 路径)。
// 只用主机已知的 shape 选路径，不读取 GPU counts；这是本轮有限扫参的启发式。
inline int moe_kernel9_default_config(int m,int n,int k) {
    if(m<=64)return n==2432 && m>1?6:7;
    if(n==2432 || m>4096)return 5;
    return n==768?0:3;
}
// 函数: moe_launch_kernel9_shape<T, N, K>
// 用途: 按编译期固定的 (N,K) 实例化并启动 kernel9：先算 tile 容量上界与 grid 上限；
//       config>=6 时启动 split-K + reduce，否则按 config 展开 BM/WM/WN/STAGES 组合启动主内核。
// 输入: c / a / b、meta、experts、m、config、blocks(0 表示不限制)、stream、partial(Split-K 缓冲)。
// 输出: 无返回值(仅发起 kernel 启动)；config 非法时抛 std::runtime_error。
template<class T,int N,int K> void moe_launch_kernel9_shape(
    T* c,const T* a,const T* b,const GroupedMetadata9* meta,
    int experts,int m,int config,int blocks,cudaStream_t stream,float* partial
) {
    int bm=moe_kernel9_bm(config);
    int64_t capacity=((int64_t(m)+bm-1)/bm+std::min(m,experts)-1)*(N/128);
    unsigned grid=unsigned(std::min<int64_t>(blocks?blocks:INT32_MAX,capacity));
    if(config>=6) {
        int parts=config==6?4:8;
        moe_grouped_split_kernel9<T,N,K><<<dim3(grid,1,parts),128,3*(16+128)*32*sizeof(T),stream>>>(
            partial,a,b,meta,experts,m,parts);
        moe_grouped_reduce_kernel9<<<ceil_div(m*N,256),128,0,stream>>>(c,partial,meta,int64_t(m)*N,parts);
        return;
    }
    #define MOE9_LAUNCH(BM,WM,WN,ST) \
        moe_grouped_gemm_forward_kernel9<T,N,K,BM,WM,WN,ST><<<grid,128,ST*(BM+128)*32*sizeof(T),stream>>>(c,a,b,meta,experts)
    switch(config) {
        case 0:MOE9_LAUNCH(32,32,32,3);break;
        case 1:MOE9_LAUNCH(16,16,32,3);break;
        case 2:MOE9_LAUNCH(64,32,64,3);break;
        case 3:MOE9_LAUNCH(32,32,32,2);break;
        case 4:MOE9_LAUNCH(16,16,32,2);break;
        case 5:MOE9_LAUNCH(64,32,64,2);break;
        default:throw std::runtime_error("kernel9 config must be 0..7");
    }
    #undef MOE9_LAUNCH
}
// 函数: moe_launch_kernel9<T>
// 用途: kernel9 的对外统一入口：选定 config、校验 shape 与参数合法性、(可选)先跑 prepare 生成元数据、
//       (可选)再按 n 分派到对应的 (N,K) 实例，最后检查 launch 错误。
// 输入: c / a / b、meta、counts(int64)、experts、m / n / k、stream、config(-1 表示自动)、blocks、
//       prepare / compute 开关、partial。
// 输出: 无返回值；shape/config 不被支持或 launch 失败时抛 std::runtime_error。
template<class T> void moe_launch_kernel9(
    T* c,const T* a,const T* b,GroupedMetadata9* meta,const int64_t* counts,
    int experts,int m,int n,int k,cudaStream_t stream=nullptr,
    int config=-1,int blocks=0,bool prepare=true,bool compute=true,float* partial=nullptr
) {
    static_assert(!std::is_same_v<T,float>);
    if(config==-1)config=moe_kernel9_default_config(m,n,k);
    if(!moe_is_kernel9_target(experts,n,k) || m<0 || blocks<0 || config<0 || config>7 ||
       (config>=6 && (m>64 || (m && !partial))))
        throw std::runtime_error("unsupported kernel9 shape/config");
    if(!m)return;
    if(prepare)moe_grouped_prepare_kernel9<<<1,32,0,stream>>>(meta,counts,experts,m,moe_kernel9_bm(config),n);
    if(compute) {
        if(n==2432)moe_launch_kernel9_shape<T,2432,768>(c,a,b,meta,experts,m,config,blocks,stream,partial);
        else if(n==768)moe_launch_kernel9_shape<T,768,2432>(c,a,b,meta,experts,m,config,blocks,stream,partial);
        else moe_launch_kernel9_shape<T,1024,1024>(c,a,b,meta,experts,m,config,blocks,stream,partial);
    }
    auto status=cudaGetLastError();
    if(status!=cudaSuccess)throw std::runtime_error(std::string("kernel9 launch: ")+cudaGetErrorString(status));
}

// ============================================================================
// ------------------------- test --------------------------
// 函数: run_benchmark<T>
// 用途: 单个 dtype 下的分组 GEMM 校验与性能测试主循环：构造 A/B，先用 cuBLAS 逐专家算参考结果
//       (并对参考做 CPU 抽查)，再按 --kernel 逐个测 kernel1..kernel9：结果比对 + 计时，
//       同时处理各 kernel 的形状/依赖可用性判断(SKIP，或 fallback 到 kernel6)。
// 输入: GemmOptions o(dtype / m / experts / n / k / counts / distribution / kernel / bench / repeats / seed)、
//       zeros(是否把 A 置零，用于覆盖零输入分支)。
// 输出: bool，true 表示被测 kernel 全部通过校验；过程中打印 counts、DISPATCH/SKIP 说明与 RESULT 性能行。
template<class T> bool run_benchmark(
    const GemmOptions& o,
    bool zeros=false
) {
    auto counts=make_counts(o);std::vector<int> offsets(counts.size()+1,0);
    for(size_t e=0;e<counts.size();++e)offsets[e+1]=offsets[e]+counts[e];
    const int m=offsets.back(),n=o.n,k=o.k,experts=counts.size();
    const int max_m=*std::max_element(counts.begin(),counts.end());
    if((size_t(m)*k+size_t(m)*n+size_t(experts)*k*n)*sizeof(T)>size_t(6)*1024*1024*1024)
        throw std::runtime_error("actual grouped working set exceeds 6 GiB");
    auto a=gemm_random<T>(size_t(m)*k,o.seed,zeros),b=gemm_random<T>(size_t(experts)*k*n,o.seed+1);
    DeviceBuffer<T> da(a.size()),db(b.size()),dc(size_t(m)*n),dr(size_t(m)*n);
    DeviceBuffer<int> dcounts(counts.size()),doffsets(offsets.size());
    DeviceBuffer<int64_t> dcounts9(counts.size());DeviceBuffer<GroupedMetadata9> meta9(1);
    dcounts9.upload(std::vector<int64_t>(counts.begin(),counts.end()));
    da.upload(a);db.upload(b);dcounts.upload(counts);doffsets.upload(offsets);
    BlasHandle blas;
    auto blas_loop=[&](T* output) {
        for(int e=0;e<experts;++e)gemm_cublas(blas.handle,output+size_t(offsets[e])*n,
            da.ptr+size_t(offsets[e])*k,db.ptr+size_t(e)*k*n,counts[e],n,k);
    };
    auto cpu_check=[&](const std::vector<T>& output) {
        for(int e=0;e<experts;++e)if(!gemm_cpu_check(a,b,output,counts[e],n,k,
            size_t(offsets[e])*k,size_t(e)*k*n,size_t(offsets[e])*n))return false;
        return true;
    };
    dr.poison();blas_loop(dr.ptr);auto ref=dr.download();if(!cpu_check(ref))return false;
    printf("GROUPED dtype=%s rows=%d E=%d N=%d K=%d counts=",o.dtype.c_str(),m,experts,n,k);
    for(int e=0;e<experts;++e)printf("%s%d",e?";":"",counts[e]);puts("");
    for(int v=1;v<=9;++v) {
        if(o.kernel && o.kernel!=v)continue;
        if(v==9 && (std::is_same_v<T,float> || !moe_is_kernel9_target(experts,n,k))) {
            if(o.kernel==9)throw std::runtime_error("kernel9 needs fp16/bf16, E<=16, supported N/K");
            puts("SKIP kernel9: outside supported dtype/shape");continue;
        }
        int config9=moe_kernel9_default_config(m,n,k);
        DeviceBuffer<float> split9(v==9 && config9>=6?size_t(m)*n*(config9==6?4:8):0);
        if(v==5) {
            bool available=false;
#ifdef USE_CUTLASS
            available=!std::is_same_v<T,float> && n%8==0 && k%8==0;
#endif
            if(!available) {
                if(o.kernel==5)throw std::runtime_error("kernel5 requires USE_CUTLASS, fp16/bf16, N/K multiples of 8");
                puts("SKIP kernel5: requires USE_CUTLASS, fp16/bf16, N/K multiples of 8");continue;
            }
        }
        bool fixed=v==7 && std::is_same_v<T,half> && moe_is_fixed_target(counts,n,k);
        if(v==7)puts(fixed?"DISPATCH kernel7: fixed FP16 32x128x32, 3 stages":"DISPATCH kernel7: fallback to kernel6 for this dtype/shape");
        bool dynamic=v==8 && std::is_same_v<T,half> && moe_is_kernel8_target(counts,n,k);
        if(v==8)puts(dynamic?"DISPATCH kernel8: FP16 E=16 sum(M)=2048 N=K=1024, variable counts":"DISPATCH kernel8: fallback to kernel6 for this dtype/shape");
        bool wide=(v==6 || v==7 || v==8) && !std::is_same_v<T,float> && moe_use_wide_tiles(counts,n,k);
        auto ht=v==9 ? std::vector<GroupTile>() : fixed ? make_fixed_tiles(counts) : dynamic ? make_kernel8_tiles(counts) : (v==6 || v==7 || v==8) ? (wide ? make_optimized_tiles<32,128,128>(counts,n,true) : make_optimized_tiles(counts,n,!std::is_same_v<T,float>)) : make_tiles(counts,n,v==3?3:4);
        DeviceBuffer<GroupTile> dt(ht.size());dt.upload(ht);
        std::function<void()> cutlass_run;
#ifdef USE_CUTLASS
        // FP32 参考保持完整 FP32 精度；此处只构造低精度 Tensor Core baseline。
        using LowT=std::conditional_t<std::is_same_v<T,float>,half,T>;
        std::unique_ptr<CutlassGrouped<LowT>> cutlass;
        if(v==5) {
            cutlass=std::make_unique<CutlassGrouped<LowT>>(reinterpret_cast<LowT*>(dc.ptr),
                reinterpret_cast<LowT*>(da.ptr),reinterpret_cast<LowT*>(db.ptr),counts,offsets,n,k);
            cutlass_run=[&]{cutlass->run();};
        }
#endif
        auto launch=[&] {
            if(!m)return;
            if(v==1)moe_grouped_gemm_forward_kernel1<<<dim3(ceil_div(n,16),ceil_div(max_m,16),experts),dim3(16,16)>>>(
                dc.ptr,da.ptr,db.ptr,dcounts.ptr,doffsets.ptr,n,k);
            else if(v==2)blas_loop(dc.ptr);
            else if(v==3)moe_grouped_gemm_forward_kernel3<<<ht.size(),dim3(16,16)>>>(
                dc.ptr,da.ptr,db.ptr,dcounts.ptr,doffsets.ptr,dt.ptr,n,k);
            else if(v==4)moe_grouped_gemm_forward_kernel4<<<ht.size(),dim3(16,16)>>>(
                dc.ptr,da.ptr,db.ptr,dcounts.ptr,doffsets.ptr,dt.ptr,n,k);
            else if(v==9) {
                if constexpr(!std::is_same_v<T,float>)moe_launch_kernel9(dc.ptr,da.ptr,db.ptr,
                    meta9.ptr,dcounts9.ptr,experts,m,n,k,nullptr,-1,0,true,true,split9.ptr);
            }
            else if(v==7 && fixed) {
                if constexpr(std::is_same_v<T,half>)moe_grouped_gemm_forward_kernel7<<<ht.size(),128,3*(32*32+32*128)*sizeof(half)>>>(dc.ptr,da.ptr,db.ptr,dcounts.ptr,doffsets.ptr,dt.ptr);
            }
            else if(v==8 && dynamic) {
                if constexpr(std::is_same_v<T,half>)moe_grouped_gemm_forward_kernel8<<<ht.size(),128,3*(32*32+32*128)*sizeof(half)>>>(dc.ptr,da.ptr,db.ptr,dcounts.ptr,doffsets.ptr,dt.ptr);
            }
            else if(v==6 || v==7 || v==8) {
                if constexpr(std::is_same_v<T,float>)moe_grouped_gemm_forward_kernel6_fp32<<<ht.size(),128>>>(dc.ptr,da.ptr,db.ptr,dcounts.ptr,doffsets.ptr,dt.ptr,n,k);
                else if(wide)moe_grouped_gemm_forward_kernel6_mma<T,32,128,16,64,128><<<ht.size(),128>>>(dc.ptr,da.ptr,db.ptr,dcounts.ptr,doffsets.ptr,dt.ptr,int(ht.size()),n,k);
                else moe_grouped_gemm_forward_kernel6_mma<T><<<ht.size(),128>>>(dc.ptr,da.ptr,db.ptr,dcounts.ptr,doffsets.ptr,dt.ptr,int(ht.size()),n,k);
            }
            else cutlass_run();
            CUDA_CHECK(cudaGetLastError());
        };
        dc.poison();launch();auto out=dc.download();std::string label="kernel"+std::to_string(v);
        if(!gemm_validate(out,ref,label.c_str()) || !cpu_check(out))return false;
        if(o.bench && m) {
            auto t=gemm_benchmark(launch,o.repeats);
            printf("RESULT grouped,%s,%d,%d,%d,%d,%d,%.6f,%.6f,%.4f\n",o.dtype.c_str(),m,experts,n,k,v,
                t.gpu_ms,t.wall_ms,2.*m*n*k/(t.gpu_ms*1e9));
        }
    }
    return true;
}

// ------------------------- test --------------------------
// 函数: run_dtype<T>
// 用途: 按 dtype 组织测试用例集。--self-test 时遍历多组 counts 分布(空专家、尾块、超长 K、
//       固定形状 E=16 / sum(M)=2048 以及 kernel9 的多种 N/K)以保证覆盖；
//       非 self-test 时只跑一次用户给定的配置。自测期间强制关闭计时。
// 输入: GemmOptions o(按值传入，内部会改写 counts / n / k / kernel / seed 等字段)。
// 输出: bool，全部用例通过返回 true，任一用例失败立即返回 false。
template<class T> bool run_dtype(GemmOptions o) {
    if(!o.self_test)return run_benchmark<T>(o);
    o.bench=false;
    if(o.kernel==9) {
        for(const char* pattern:{"0,0","0,1","1,0","31,33","0,129","8691,12526"}) {
            o.counts=pattern;
            for(auto nk:std::vector<std::pair<int,int>>{{2432,768},{768,2432},{1024,1024}}) {
                o.n=nk.first;o.k=nk.second;
                for(int seed:{0,17}){o.seed=seed;if(!run_benchmark<T>(o))return false;}
            }
        }
        o.counts="64,96,160,192,64,96,160,192,64,96,160,192,64,96,160,192";
        o.n=o.k=1024;return run_benchmark<T>(o,true);
    }
    const char* patterns[]={"0,0,0","1","0,1,0,17,3","16,33,0,65,127","1,1,1,1,1,1,1,1","256,0,1,0,0,7,0,2"};
    for(const char* pattern:patterns) {
        o.counts=pattern;
        for(auto nk:std::vector<std::pair<int,int>>{{31,19},{64,64},{128,256}}) {
            o.n=nk.first;o.k=nk.second;
            for(int seed:{0,17}){o.seed=seed;if(!run_benchmark<T>(o))return false;}
        }
    }
    o.counts="0,17,3,1";o.n=64;o.k=32;
    if(!run_benchmark<T>(o,true))return false;
    // 覆盖 kernel6 的专家分块切换、向量对齐、M/N/K 尾块和长 K。
    o.counts="0,1,2,7,8,15,16,17,31,32,33,63,64,65,129,0";
    for(auto nk:std::vector<std::pair<int,int>>{{1,1},{8,8},{65,33},{512,512}}) {
        o.n=nk.first;o.k=nk.second;
        for(int seed:{0,17}) {o.seed=seed;if(!run_benchmark<T>(o))return false;}
    }
    o.counts="0,1,0,3,17,0";o.n=31;o.k=16383;
    if(!run_benchmark<T>(o))return false;
    if constexpr(std::is_same_v<T,half>) {
        o.counts="64,96,160,192,64,96,160,192,64,96,160,192,64,96,160,192";o.n=o.k=1024;
        for(int seed:{0,17}){o.seed=seed;if(!run_benchmark<T>(o))return false;}
        if(!run_benchmark<T>(o,true))return false;
        if(o.kernel==0 || o.kernel==8) {
            // 固定总 M 的优化路径：均匀、集中、空专家、小专家和非 32 倍数。
            std::vector<std::vector<int>> patterns(7,std::vector<int>(16,0));
            patterns[0].assign(16,128);
            patterns[1][0]=2048;patterns[2][15]=2048;
            patterns[3][0]=1;patterns[3][15]=2047;
            patterns[4].assign(16,127);patterns[4][15]=143;
            patterns[5]={0,1,2,7,8,15,16,17,31,32,33,63,64,65,129,0};
            int used=0;for(int m:patterns[5])used+=m;patterns[5][15]=2048-used;
            patterns[6][0]=1536;
            for(int e=1;e<16;++e)patterns[6][e]=512/15+(e<=512%15);
            // 随机切分而非只做均匀 multinomial，产生更多空专家和尾块。
            for(int seed:{0,17,43}) {
                std::mt19937 rng(seed);std::uniform_int_distribution<int> pick(0,2048);
                std::vector<int> cuts={0,2048};for(int e=0;e<15;++e)cuts.push_back(pick(rng));
                std::sort(cuts.begin(),cuts.end());std::vector<int> counts(16);
                for(int e=0;e<16;++e)counts[e]=cuts[e+1]-cuts[e];patterns.push_back(counts);
            }
            o.kernel=8;
            for(const auto& counts:patterns) {
                std::ostringstream text;
                for(size_t e=0;e<counts.size();++e)text<<(e?",":"")<<counts[e];
                o.counts=text.str();
                for(int seed:{0,17}){o.seed=seed;if(!run_benchmark<T>(o))return false;}
            }
            if(!run_benchmark<T>(o,true))return false;
        }
    }
    return true;
}
// ------------------------- test --------------------------
// 函数: main
// 用途: 程序入口。解析命令行(--m / --experts / --n / --k / --dtype / --kernel / --counts / ...)
//       并打印设备信息；self-test 模式下依次跑 fp32 / fp16 / bf16(kernel!=9 时)，
//       否则按 --dtype 选择单个 dtype 运行；最后打印 ALL CHECKS PASSED 或 CHECK FAILED。
// 输入: argc / argv(命令行参数)。
// 输出: int 退出码，0 = 全部通过，1 = 校验失败或抛异常(异常信息写到 stderr)。
int main(
    int argc,
    char** argv
) {
    try {
        auto o=gemm_options(argc,argv,9);gemm_device_info();bool ok=true;
        if(o.self_test) {
            if(o.kernel!=9){o.dtype="fp32";ok &= run_dtype<float>(o);}
            o.dtype="fp16";ok &= run_dtype<half>(o);
            o.dtype="bf16";ok &= run_dtype<__nv_bfloat16>(o);
        } else if(o.dtype=="fp32")ok=run_dtype<float>(o);
        else if(o.dtype=="fp16")ok=run_dtype<half>(o);
        else ok=run_dtype<__nv_bfloat16>(o);
        puts(ok?"ALL CHECKS PASSED":"CHECK FAILED");return ok?0:1;
    } catch(const std::exception& e){fprintf(stderr,"%s\n",e.what());return 1;}
}
