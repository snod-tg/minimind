# my_cuda_kernels Python API

在项目根目录安装 `python -m pip install --no-deps --no-build-isolation -e .`，同一解释器中的模型直接导入。

```python
from my_cuda_kernels.grouped_gemm import load_library, grouped_gemm, GemmWorkspace
load_library()  # build/grouped_gemm/current/my_cuda_grouped_split.so
y = grouped_gemm(x, packed_b, counts)
workspace = GemmWorkspace.allocate(x, packed_b, capacity=4096)
y = workspace.run(x, packed_b, counts)
```

x 是按专家打包的 [M,K]，packed_b 是连续 [E,K,N]；counts 是 CUDA int64 [E]，非负且总和为 M。输入/权重/输出为 BF16 或 FP16，FP32 累加；支持 E=1～16、(K,N)=(768,2432)/(2432,768)/(1024,1024)。M≤256 默认 Decode，其余 Prefill；动态专家分配来自 GPU counts。只提供前向，要求 inference_mode；FP32 累加的 BF16 输出与原 PyTorch BF16 中间归约有不同数值契约。

debug_counts=True 会同步检查 counts 值。工作区输出是复用视图，长期保留需 clone；独立 stream 需独立工作区和明确依赖。FakeTensor 和分配接口可编译，完整模型数值/通信不能由单算子测试替代。

```python
from my_cuda_kernels.ep_ops import load_library
from my_cuda_kernels.ep import Workspace, combine_inference
load_library()  # build/ep/current/my_cuda_ep.so
```

EP 包提供稳定分桶、pack/gather/combine 的 CUDA 张量操作及训练 autograd；Router、NCCL 和原专家运行由 MiniMind 编排。专家模块权重缓存与完整 MLP 位于 MiniMind 的 model/backends。

旧 kernel9 接口通过 my_cuda_kernels.kernel9 使用。构建与验证见 [命令](../../doc/commands/local_workflow.md)；模型接入见 [MiniMind](../../../minimind/readme_ep.md)。
