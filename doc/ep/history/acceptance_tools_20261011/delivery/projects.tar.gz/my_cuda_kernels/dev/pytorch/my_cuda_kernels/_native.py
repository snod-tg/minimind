"""Resolve native builds without depending on an experiment directory."""
import os
from pathlib import Path

LIBRARIES={"ep":"my_cuda_ep.so", "grouped_gemm":"my_cuda_grouped_split.so", "kernel9":"my_cuda_kernel9.so"}

def repository_root():
    return Path(__file__).resolve().parents[3]

def resolve_library(kind, path=None):
    root=Path(os.environ.get("MY_CUDA_KERNELS_BUILD", repository_root()/"build"))
    selected=Path(path).expanduser() if path is not None else root/kind/"current"/LIBRARIES[kind]
    selected=selected.resolve()
    if not selected.is_file():
        raise FileNotFoundError(f"Native library missing: {selected}. Build it with: python script/build.py {kind}")
    return selected
