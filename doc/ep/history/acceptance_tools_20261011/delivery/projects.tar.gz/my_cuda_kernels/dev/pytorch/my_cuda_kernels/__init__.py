"""CUDA operators used through ordinary Python imports. Native libraries load explicitly."""
__version__ = "0.1.0"
