// Kernel9 launcher for the PyTorch dispatcher; keep all GEMM math in the teaching source.
#define main grouped_gemm_teaching_main
#include "moe_grouped_gemm_forward.cu"
#undef main

size_t grouped_gemm9_metadata_bytes() {return sizeof(GroupedMetadata9);}
int grouped_gemm9_parts(int m,int n,int k) {
    int config=moe_kernel9_default_config(m,n,k);
    return config<6?0:config==6?4:8;
}
void grouped_gemm9_launch(void* out,const void* x,const void* b,const int64_t* counts,
    void* metadata,float* partial,int dtype,int experts,int m,int n,int k,cudaStream_t stream) {
    auto* meta=static_cast<GroupedMetadata9*>(metadata);
    if(dtype==0)moe_launch_kernel9(static_cast<half*>(out),static_cast<const half*>(x),static_cast<const half*>(b),
        meta,counts,experts,m,n,k,stream,-1,0,true,true,partial);
    else moe_launch_kernel9(static_cast<__nv_bfloat16*>(out),static_cast<const __nv_bfloat16*>(x),
        static_cast<const __nv_bfloat16*>(b),meta,counts,experts,m,n,k,stream,-1,0,true,true,partial);
}
