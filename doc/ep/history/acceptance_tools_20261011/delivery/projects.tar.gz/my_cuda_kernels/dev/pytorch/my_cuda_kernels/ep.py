"""Generic EP partition, capacity and native-precision merge helpers."""
import torch
from .ep_ops import load_library

def combine_inference(returned,weights,inverse,topk,out):
    if topk<=2:
        torch.ops.my_cuda_ep.combine_out(returned,weights,inverse,topk,out)
    else:
        # Keep the original parallel reduction and its BF16 rounding semantics.
        weighted=torch.empty((inverse.numel(),out.shape[1]),device=out.device,dtype=out.dtype)
        torch.ops.my_cuda_ep.combine_out(returned,weights,inverse,1,weighted)
        indices=torch.arange(out.shape[0],device=out.device).repeat_interleave(topk)
        out.zero_();out.index_add_(0,indices,weighted)

class Workspace:
    def __init__(self,reuse=True):
        self.reuse=reuse
        self.buffers={}
        self.growth=0
    def get(self,name,shape,dtype,device):
        if not self.reuse:return torch.empty(shape,dtype=dtype,device=device)
        count=1
        for size in shape: count*=size
        key=(name,dtype,device)
        old=self.buffers.get(key)
        if old is None or old.numel()<count:
            capacity=max(256,1<<(max(1,count)-1).bit_length())
            old=torch.empty(capacity,dtype=dtype,device=device)
            self.buffers[key]=old
            self.growth+=1
        return old[:count].view(shape)
    def sort(self,ids,divisor,name,bins=2,masked=False):
        n=ids.numel();b=(n+255)//256;device=ids.device
        perm=self.get(name+'_perm',(n,),torch.int64,device)
        inv=self.get(name+'_inverse',(n,),torch.int64,device)
        counts=self.get(name+'_counts',(bins,),torch.int64,device)
        pos=self.get(name+'_positions',(n,),torch.int32,device)
        blocks=self.get(name+'_blocks',(b*bins,),torch.int32,device)
        offsets=self.get(name+'_offsets',(b*bins,),torch.int32,device)
        if masked:
            torch.ops.my_cuda_ep.sort_masked_out(ids,perm,inv,counts,pos,blocks,offsets)
        else:
            torch.ops.my_cuda_ep.sort_out(ids,divisor,perm,inv,counts,pos,blocks,offsets)
        return perm,inv,counts

