# My CUDA Kernels 工作约定

- CUDA 源码统一放 dev/cuda，复用 common.h；练习版本保留可读的 native、开源对照与优化 kernel。
- 通用 Python API 放 dev/pytorch/my_cuda_kernels；不得导入 MiniMind 模型或读取模型 checkpoint。
- 编译和测量脚本放 script，单算子测试放 tests，构建输出放 build，测量输出放 result。
- 分析放 analysis，配图统一放 figures；每轮说明包含目的、执行方案、结果、调整闭环。
- 具体指令写 doc/commands，执行结果写 doc/results，方案写 doc/design；先验证数值和边界，再比较同条件耗时。
- 新脚本使用项目根目录相对路径或参数，不写死服务器用户名、日期阶段目录。正式构建只读取 dev/cuda，不复制 source 树。
- MiniMind 的训练、通信编排、权重保存、整模型测试归 MiniMind；两个项目用 editable Python 包连接，不修改 sys.path。

[项目组织](doc/design/project_structure.md) · [操作命令](doc/commands/local_workflow.md) · [目录迁移前的工作记录](doc/history/guide_before_20261009.md)
