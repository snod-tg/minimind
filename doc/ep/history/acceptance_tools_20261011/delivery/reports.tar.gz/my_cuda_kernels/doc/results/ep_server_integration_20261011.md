# EP算子包服务器接入验收

## 目的
验证正式算子包可被MiniMind普通import并通过原生精度模型对拍。

## 执行方案
使用服务器已有Python3.13.5 / PyTorch2.9.0+cu128、GCC12与nvcc；python script/build.py ep构建，随后执行MiniMind的最终权重验收。

## 结果
EP库构建和加载成功，架构sm_89、C++11 ABI=1。通用包3项CPU检查通过，MiniMind侧5项通过；6选2完整模型对拍通过。当前只构建EP库，未接入手写专家GEMM。

[模型侧结果](../../../minimind/analysis/ep6_top2_validation_and_baseline.md)

## 调整闭环
构建先完成，再切换current；实际模型数值不变后才测量。original基线绕过计数与优化EP非预期回退需分开。
